HotFetched A1 Mini Agent v1.0
================================

Purpose
-------
This local Windows agent gives the HotFetched browser UI access to:

- official N1/A1 Mini offline-package inspection;
- removable-drive discovery;
- integrity-checked SD-card staging;
- DPAPI-protected printer credential setup;
- passive update monitoring;
- post-update module verification.

Security
--------
- Listens only on 127.0.0.1:47841.
- Sensitive endpoints require a six-digit pairing code and bearer token.
- Never returns or logs the LAN access code.
- Reuses the existing Windows-DPAPI credential file.
- Does not send upgrade.start, upgrade_confirm, or consistency_confirm.
- Does not format or automatically eject drives.
- Does not overwrite a different file with the same firmware filename.

Install
-------
Double-click:

Install-HotFetched-A1Mini-Agent.cmd

The installer reuses C:\tmp\beambam-win when available. Otherwise it creates an
isolated runtime under LocalAppData and installs beambam 1.5.1.

Pair
----
Open the desktop shortcut named:

HotFetched A1 Mini Agent

It starts the local agent and opens:

http://127.0.0.1:47841/pairing

Enter the displayed code in HotFetched's A1 Mini SD Firmware Assistant.
