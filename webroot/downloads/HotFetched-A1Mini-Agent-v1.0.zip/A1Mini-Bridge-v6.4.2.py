#!/usr/bin/env python3
"""Native helper for A1Mini-Control v6.4.2.

v6.4.2 adds integrity-checked SD staging, live offline-upgrade monitoring,
post-update verification support, and the v6.4 acknowledgement fixes.

It never sends upgrade.start, upgrade_confirm, or consistency_confirm.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import http.server
import json
import os
import shutil
import socket
import socketserver
import struct
import sys
import threading
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from beambam.config import Creds
from beambam.mqtt import X2DClient


FORBIDDEN_UPGRADE_COMMANDS = {
    "start",
    "upgrade_confirm",
    "consistency_confirm",
}


def timestamp() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="milliseconds")


def compact_json(value: Any) -> str:
    return json.dumps(value, separators=(",", ":"), ensure_ascii=True)


def select_command_family(payload: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    """Return the nested command family even when top-level metadata exists."""
    for key, value in payload.items():
        if isinstance(value, dict) and "command" in value and "sequence_id" in value:
            return key, value
    raise ValueError("Payload does not contain a command family")


def parse_bimh(blob: bytes) -> dict[str, Any]:
    if blob[:4] != b"BIMH":
        raise ValueError("Not a BIMH signed container")

    header_size = struct.unpack_from("<I", blob, 0x20)[0]
    flags = [struct.unpack_from("<I", blob, offset)[0] for offset in (0x70, 0x74, 0x78, 0x7C)]
    result: dict[str, Any] = {
        "magic": "BIMH",
        "version": struct.unpack_from("<I", blob, 0x04)[0],
        "declared_total_size": struct.unpack_from("<I", blob, 0x08)[0],
        "header_size": header_size,
        "signature_size": struct.unpack_from("<I", blob, 0x24)[0],
        "payload_size": struct.unpack_from("<I", blob, 0x28)[0],
        "flags": flags,
        "plaintext_payload": flags[2] == 0,
    }

    if not result["plaintext_payload"]:
        return result

    payload = blob[header_size:]
    if len(payload) < 112:
        raise ValueError("Readable BIMH payload is too short")

    inner_name = payload[:64].split(b"\0", 1)[0].decode("ascii", errors="replace")
    data_length = struct.unpack_from("<I", payload, 68)[0]
    embedded_sha256 = payload[80:112].hex()
    data = payload[112:112 + data_length]

    if len(data) != data_length:
        raise ValueError("Readable BIMH payload length mismatch")

    calculated = hashlib.sha256(data).hexdigest()
    result.update(
        {
            "inner_name": inner_name,
            "target_code": struct.unpack_from("<I", payload, 64)[0],
            "inner_data_length": data_length,
            "inner_flags": struct.unpack_from("<I", payload, 72)[0],
            "embedded_sha256": embedded_sha256,
            "calculated_inner_sha256": calculated,
            "inner_sha256_valid": embedded_sha256 == calculated,
            "_inner_data": data,
        }
    )
    return result


def inspect_offline_package(package_path: Path) -> dict[str, Any]:
    package_path = package_path.resolve()
    if not package_path.is_file():
        raise FileNotFoundError(f"Package not found: {package_path}")

    with zipfile.ZipFile(package_path) as archive:
        bad_member = archive.testzip()
        names = archive.namelist()

        package_list_name = "ota-package-list.json.sig"
        if package_list_name not in names:
            raise ValueError("Package does not contain ota-package-list.json.sig")

        n1_names = [
            name
            for name in names
            if name.startswith("ota-n1_") and name.endswith(".json.sig")
        ]
        if len(n1_names) != 1:
            raise ValueError(f"Expected exactly one N1 manifest, found {len(n1_names)}")

        package_list_blob = archive.read(package_list_name)
        package_list_container = parse_bimh(package_list_blob)
        package_list_data = package_list_container.pop("_inner_data", None)
        if package_list_data is None:
            raise ValueError("Package list is not a readable signed JSON container")
        package_list = json.loads(package_list_data)

        n1_name = n1_names[0]
        n1_blob = archive.read(n1_name)
        n1_container = parse_bimh(n1_blob)
        n1_data = n1_container.pop("_inner_data", None)
        if n1_data is None:
            raise ValueError("N1 manifest is not a readable signed JSON container")
        n1_manifest = json.loads(n1_data)

        package_hash_rows: list[dict[str, Any]] = []
        for entry in package_list.get("packages", []):
            name = entry.get("file")
            expected = entry.get("hash")
            present = isinstance(name, str) and name in names
            calculated = hashlib.sha256(archive.read(name)).hexdigest() if present else None
            package_hash_rows.append(
                {
                    "file": name,
                    "present": present,
                    "expected_sha256": expected,
                    "calculated_sha256": calculated,
                    "valid": present and expected == calculated,
                }
            )

        component_rows: list[dict[str, Any]] = []
        for module, value in n1_manifest.items():
            if not isinstance(value, dict) or "url" not in value:
                continue
            filename = str(value["url"]).rsplit("/", 1)[-1]
            present = filename in names
            calculated_md5 = hashlib.md5(archive.read(filename)).hexdigest() if present else None
            component_rows.append(
                {
                    "module": module,
                    "version": value.get("version"),
                    "file": filename,
                    "present": present,
                    "expected_md5": value.get("sig"),
                    "calculated_md5": calculated_md5,
                    "valid": present and calculated_md5 == value.get("sig"),
                }
            )

        return {
            "package_path": str(package_path),
            "package_filename": package_path.name,
            "package_size": package_path.stat().st_size,
            "package_sha256": hashlib.sha256(package_path.read_bytes()).hexdigest(),
            "zip_integrity": bad_member is None,
            "entry_count": len(names),
            "package_list_inner_hash_valid": bool(
                package_list_container.get("inner_sha256_valid")
            ),
            "n1_manifest_inner_hash_valid": bool(
                n1_container.get("inner_sha256_valid")
            ),
            "package_hashes_valid": all(row["valid"] for row in package_hash_rows),
            "component_md5_valid": all(row["valid"] for row in component_rows),
            "model_name": n1_manifest.get("model_name"),
            "version": n1_manifest.get("version"),
            "package_list_ota_version": package_list.get("ota_ver"),
            "lower_limit": package_list.get("lower_limit"),
            "manifest_filename": n1_name,
            "manifest_sha256": hashlib.sha256(n1_blob).hexdigest(),
            "manifest_bytes": n1_blob,
            "targets": {
                key: value.get("version")
                for key, value in n1_manifest.items()
                if isinstance(value, dict) and "version" in value
            },
            "package_hash_rows": package_hash_rows,
            "component_rows": component_rows,
        }


def serializable_inspection(inspection: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in inspection.items() if key != "manifest_bytes"}



def package_integrity_checks(inspection: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        {
            "check": "ZIP integrity",
            "pass": bool(inspection.get("zip_integrity")),
        },
        {
            "check": "Package-list BIMH inner digest",
            "pass": bool(inspection.get("package_list_inner_hash_valid")),
        },
        {
            "check": "N1 manifest BIMH inner digest",
            "pass": bool(inspection.get("n1_manifest_inner_hash_valid")),
        },
        {
            "check": "Package-list member SHA-256 chain",
            "pass": bool(inspection.get("package_hashes_valid")),
        },
        {
            "check": "Manifest component MD5 chain",
            "pass": bool(inspection.get("component_md5_valid")),
        },
        {
            "check": "A1 Mini model identifier N1",
            "pass": inspection.get("model_name") == "N1",
        },
        {
            "check": "Manifest/package-list OTA version agreement",
            "pass": (
                inspection.get("version")
                == inspection.get("package_list_ota_version")
                and bool(inspection.get("version"))
            ),
        },
    ]


def assert_stageable_n1_package(inspection: dict[str, Any]) -> None:
    failed = [
        row["check"]
        for row in package_integrity_checks(inspection)
        if not row["pass"]
    ]
    if failed:
        raise ValueError(
            "Package failed integrity checks: " + ", ".join(failed)
        )


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def stage_package_command(
    package_path: Path,
    destination_root: Path,
    output_dir: Path,
) -> int:
    try:
        inspection = inspect_offline_package(package_path)
        assert_stageable_n1_package(inspection)

        package_path = package_path.resolve()
        destination_root = destination_root.resolve()

        if not destination_root.is_dir():
            raise FileNotFoundError(
                f"Destination root is not available: {destination_root}"
            )

        output_dir.mkdir(parents=True, exist_ok=False)

        free_bytes = shutil.disk_usage(destination_root).free
        required_bytes = inspection["package_size"] + (4 * 1024 * 1024)
        if free_bytes < required_bytes:
            raise OSError(
                f"Insufficient free space: need at least {required_bytes} bytes, "
                f"have {free_bytes} bytes"
            )

        target_path = destination_root / inspection["package_filename"]
        partial_path = destination_root / (
            "." + inspection["package_filename"] + ".hotfetched.partial"
        )

        if partial_path.exists():
            partial_path.unlink()

        source_hash = inspection["package_sha256"]
        status = "copied"

        if target_path.exists():
            existing_hash = sha256_file(target_path)
            if existing_hash != source_hash:
                raise FileExistsError(
                    "A different file with the same firmware package name "
                    f"already exists at {target_path}"
                )
            destination_hash = existing_hash
            status = "already_present"
        else:
            copied = 0
            total = inspection["package_size"]
            last_reported = -1
            copy_hash = hashlib.sha256()

            with package_path.open("rb") as source, partial_path.open("xb") as target:
                while True:
                    chunk = source.read(1024 * 1024)
                    if not chunk:
                        break
                    target.write(chunk)
                    copy_hash.update(chunk)
                    copied += len(chunk)

                    percent = int((copied * 100) / total) if total else 100
                    bucket = min(100, (percent // 10) * 10)
                    if bucket != last_reported:
                        print(
                            f"STAGE_PROGRESS {bucket}% "
                            f"({copied}/{total} bytes)",
                            file=sys.stderr,
                            flush=True,
                        )
                        last_reported = bucket

                target.flush()
                os.fsync(target.fileno())

            copied_hash = copy_hash.hexdigest()
            if copied_hash != source_hash:
                partial_path.unlink(missing_ok=True)
                raise OSError("Copied firmware hash differs from source hash")

            os.replace(partial_path, target_path)
            destination_hash = sha256_file(target_path)

            if destination_hash != source_hash:
                raise OSError(
                    "Final SD-card firmware hash differs from source hash"
                )

        summary = {
            "operation": "firmware_stage_sd",
            "timestamp": timestamp(),
            "status": status,
            "source_path": str(package_path),
            "destination_root": str(destination_root),
            "destination_path": str(target_path),
            "source_sha256": source_hash,
            "destination_sha256": destination_hash,
            "hash_match": source_hash == destination_hash,
            "package": serializable_inspection(inspection),
            "integrity_checks": package_integrity_checks(inspection),
            "output_dir": str(output_dir),
        }

        (output_dir / "staging-record.json").write_text(
            json.dumps(summary, indent=2) + "\n",
            encoding="utf-8",
        )
        print(compact_json(summary))
        return 0
    except Exception as exc:
        print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
        return 1

def status_command(timeout: float) -> int:
    full_state_event = threading.Event()
    state_holder: dict[str, Any] = {}

    def on_state(message: dict[str, Any]) -> None:
        if not isinstance(message, dict):
            return
        print_state = message.get("print")
        if not isinstance(print_state, dict):
            return
        if print_state.get("command") == "push_status" and print_state.get("msg") == 0:
            state_holder["message"] = message
            full_state_event.set()

    client = X2DClient(Creds.resolve_default(), on_state=on_state)

    try:
        client.connect(timeout=timeout)
        request = {
            "pushing": {
                "sequence_id": str(int(time.time() * 1000)),
                "command": "pushall",
            }
        }
        client.publish(request, qos=0)

        if not full_state_event.wait(timeout):
            print(
                compact_json(
                    {
                        "error": "No full push_status snapshot before timeout",
                        "timeout": timeout,
                    }
                )
            )
            return 2

        print(compact_json(state_holder["message"]))
        return 0
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    finally:
        try:
            client.disconnect()
        except Exception:
            pass


def send_command(payload_base64: str, timeout: float) -> int:
    try:
        payload = json.loads(base64.b64decode(payload_base64).decode("utf-8"))
        family, request_body = select_command_family(payload)
    except Exception as exc:
        print(f"Invalid payload: {exc}", file=sys.stderr)
        return 1

    sequence_id = str(request_body.get("sequence_id", ""))
    command = request_body.get("command")

    if family == "upgrade" and command in FORBIDDEN_UPGRADE_COMMANDS:
        print(
            f"Blocked forbidden firmware command: upgrade.{command}",
            file=sys.stderr,
        )
        return 9

    ack_event = threading.Event()
    ack_holder: dict[str, Any] = {}

    def on_state(message: dict[str, Any]) -> None:
        if not isinstance(message, dict):
            return
        section = message.get(family)
        if not isinstance(section, dict):
            return
        if str(section.get("sequence_id", "")) != sequence_id:
            return
        if command is not None and section.get("command") != command:
            return

        ack_holder["message"] = message
        ack_event.set()

    client = X2DClient(Creds.resolve_default(), on_state=on_state)

    try:
        client.connect(timeout=timeout)
        client.publish(payload, qos=0)

        if not ack_event.wait(timeout):
            print(
                compact_json(
                    {
                        "acknowledged": False,
                        "family": family,
                        "command": command,
                        "sequence_id": sequence_id,
                        "error": "No matching printer acknowledgement before timeout",
                    }
                )
            )
            return 3

        message = ack_holder["message"]
        section = message[family]
        result = section.get("result")
        reason = section.get("reason")
        err_code_raw = section.get("err_code")
        try:
            err_code = int(err_code_raw) if err_code_raw is not None else 0
        except (TypeError, ValueError):
            err_code = -1

        accepted = (
            err_code == 0
            and result in (None, "", "success")
            and reason in (None, "", "success")
        )

        print(
            compact_json(
                {
                    "acknowledged": True,
                    "accepted": accepted,
                    "family": family,
                    "command": command,
                    "sequence_id": sequence_id,
                    "result": result,
                    "reason": reason,
                    "err_code": err_code_raw,
                    "err_code_hex": (
                        f"0x{err_code:08X}" if err_code >= 0 else None
                    ),
                    "response": message,
                }
            )
        )
        return 0 if accepted else 4
    except KeyboardInterrupt:
        return 130
    except Exception as exc:
        print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    finally:
        try:
            client.disconnect()
        except Exception:
            pass


class ExactManifestHandler(http.server.BaseHTTPRequestHandler):
    manifest_name = ""
    manifest_bytes = b""
    request_log_path: Path | None = None

    def _log_request(self, status_code: int) -> None:
        if self.request_log_path is None:
            return
        record = {
            "timestamp": timestamp(),
            "client": self.client_address[0],
            "method": self.command,
            "path": self.path,
            "status": status_code,
            "user_agent": self.headers.get("User-Agent"),
        }
        with self.request_log_path.open("a", encoding="utf-8", newline="\n") as handle:
            handle.write(compact_json(record) + "\n")

    def _serve(self, include_body: bool) -> None:
        expected = "/" + self.manifest_name
        if self.path != expected:
            self.send_response(404)
            self.send_header("Content-Length", "0")
            self.end_headers()
            self._log_request(404)
            return

        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Length", str(len(self.manifest_bytes)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        if include_body:
            self.wfile.write(self.manifest_bytes)
        self._log_request(200)

    def do_GET(self) -> None:
        self._serve(include_body=True)

    def do_HEAD(self) -> None:
        self._serve(include_body=False)

    def log_message(self, format: str, *args: Any) -> None:
        return


class ReusableThreadingHTTPServer(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def resolve_local_ip(printer_ip: str) -> str:
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect((printer_ip, 9))
        return str(sock.getsockname()[0])
    finally:
        sock.close()


def find_firmware_entries(value: Any) -> list[dict[str, Any]]:
    found: list[dict[str, Any]] = []
    if isinstance(value, dict):
        firmware = value.get("firmware")
        if isinstance(firmware, dict):
            found.append(firmware)
        elif isinstance(firmware, list):
            found.extend(item for item in firmware if isinstance(item, dict))
        for child in value.values():
            found.extend(find_firmware_entries(child))
    elif isinstance(value, list):
        for child in value:
            found.extend(find_firmware_entries(child))
    return found


def offer_probe_command(
    package_path: Path,
    printer_ip: str,
    expected_version: str,
    offer_sequence: str,
    history_sequence: str,
    output_dir: Path,
    timeout: float,
) -> int:
    inspection = inspect_offline_package(package_path)

    required_validations = (
        inspection["zip_integrity"],
        inspection["package_list_inner_hash_valid"],
        inspection["n1_manifest_inner_hash_valid"],
        inspection["package_hashes_valid"],
        inspection["component_md5_valid"],
        inspection["model_name"] == "N1",
        inspection["version"] == expected_version,
        inspection["package_list_ota_version"] == expected_version,
    )
    if not all(required_validations):
        print(
            compact_json(
                {
                    "error": "Offline package validation failed or target version mismatch",
                    "inspection": serializable_inspection(inspection),
                }
            )
        )
        return 7

    output_dir.mkdir(parents=True, exist_ok=False)
    reports_path = output_dir / "reports.jsonl"
    http_log_path = output_dir / "http-requests.jsonl"
    summary_path = output_dir / "summary.json"
    offer_request_path = output_dir / "request-offer.json"
    history_request_path = output_dir / "request-history.json"
    manifest_path = output_dir / inspection["manifest_filename"]
    inspection_path = output_dir / "package-inspection.json"

    manifest_path.write_bytes(inspection["manifest_bytes"])
    inspection_path.write_text(
        json.dumps(serializable_inspection(inspection), indent=2) + "\n",
        encoding="utf-8",
    )

    local_ip = resolve_local_ip(printer_ip)

    ExactManifestHandler.manifest_name = inspection["manifest_filename"]
    ExactManifestHandler.manifest_bytes = inspection["manifest_bytes"]
    ExactManifestHandler.request_log_path = http_log_path

    server = ReusableThreadingHTTPServer(("0.0.0.0", 0), ExactManifestHandler)
    server_thread = threading.Thread(target=server.serve_forever, daemon=True)
    server_thread.start()
    port = int(server.server_address[1])
    manifest_url = f"http://{local_ip}:{port}/{inspection['manifest_filename']}"

    offer_payload = {
        "user_id": "0",
        "upgrade": {
            "sequence_id": offer_sequence,
            "command": "upgrade_history",
            "src_id": 2,
            "firmware_optional": {
                "firmware": {
                    "version": expected_version,
                    "url": manifest_url,
                    "force_update": False,
                    "description": "HotFetched guarded same-version offer probe",
                    "status": "release",
                },
                "ams": [],
            },
        },
    }
    history_payload = {
        "upgrade": {
            "sequence_id": history_sequence,
            "command": "get_history",
        }
    }

    offer_request_path.write_text(json.dumps(offer_payload, indent=2) + "\n", encoding="utf-8")
    history_request_path.write_text(
        json.dumps(history_payload, indent=2) + "\n",
        encoding="utf-8",
    )

    offer_ack_event = threading.Event()
    history_event = threading.Event()
    offer_ack: dict[str, Any] | None = None
    history_response: dict[str, Any] | None = None
    action_started = False
    observed_upgrade_states: list[dict[str, Any]] = []
    lock = threading.Lock()

    def on_state(message: dict[str, Any]) -> None:
        nonlocal offer_ack, history_response, action_started

        with lock:
            with reports_path.open("a", encoding="utf-8", newline="\n") as handle:
                handle.write(
                    compact_json(
                        {
                            "timestamp": timestamp(),
                            "message": message,
                        }
                    )
                    + "\n"
                )

            upgrade = message.get("upgrade")
            if isinstance(upgrade, dict):
                sequence_id = str(upgrade.get("sequence_id", ""))
                command = upgrade.get("command")
                if sequence_id == offer_sequence and command == "upgrade_history":
                    offer_ack = message
                    offer_ack_event.set()
                if sequence_id == history_sequence and command == "get_history":
                    history_response = message
                    history_event.set()

            print_state = message.get("print")
            if isinstance(print_state, dict):
                upgrade_state = print_state.get("upgrade_state")
                if isinstance(upgrade_state, dict):
                    observed_upgrade_states.append(
                        {
                            "timestamp": timestamp(),
                            "upgrade_state": upgrade_state,
                        }
                    )
                    status = str(upgrade_state.get("status", ""))
                    if status not in ("", "IDLE", "UPGRADE_SUCCESS"):
                        action_started = True

    client = X2DClient(Creds.resolve_default(), on_state=on_state)
    error: str | None = None

    try:
        client.connect(timeout=timeout)
        client.publish(offer_payload, qos=0)

        # Do not depend on an undocumented offer acknowledgement. Give the
        # printer a brief processing window, then issue the documented
        # read-only get_history request and evaluate the returned record.
        offer_ack_event.wait(min(2.5, timeout / 3.0))
        time.sleep(0.5)
        client.publish(history_payload, qos=0)
        history_event.wait(timeout)
    except KeyboardInterrupt:
        error = "Canceled"
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
    finally:
        try:
            client.disconnect()
        except Exception:
            pass
        server.shutdown()
        server.server_close()
        server_thread.join(timeout=2.0)

    offer_section = (
        offer_ack.get("upgrade")
        if isinstance(offer_ack, dict) and isinstance(offer_ack.get("upgrade"), dict)
        else {}
    )
    history_section = (
        history_response.get("upgrade")
        if isinstance(history_response, dict)
        and isinstance(history_response.get("upgrade"), dict)
        else {}
    )

    def normalize_err_code(section: dict[str, Any]) -> tuple[int | None, str | None]:
        raw = section.get("err_code")
        if raw is None:
            return 0, "0x00000000"
        try:
            value = int(raw)
        except (TypeError, ValueError):
            return None, None
        return value, f"0x{value:08X}"

    offer_err_code, offer_err_code_hex = normalize_err_code(offer_section)
    history_err_code, history_err_code_hex = normalize_err_code(history_section)

    offer_accepted = offer_ack is not None and offer_err_code == 0
    history_accepted = history_response is not None and history_err_code == 0

    firmware_optional = history_section.get("firmware_optional") if history_accepted else None
    entries = find_firmware_entries(firmware_optional)
    matching_entries = [
        entry
        for entry in entries
        if str(entry.get("version", "")) == expected_version
        and str(entry.get("url", "")) == manifest_url
    ]

    http_requests = 0
    if http_log_path.exists():
        http_requests = len(http_log_path.read_text(encoding="utf-8").splitlines())

    summary = {
        "operation": "guarded_same_version_firmware_offer_probe",
        "timestamp": timestamp(),
        "error": error,
        "package": serializable_inspection(inspection),
        "manifest_url": manifest_url,
        "offer_sequence": offer_sequence,
        "history_sequence": history_sequence,
        "offer_response_received": offer_ack is not None,
        "offer_accepted": offer_accepted,
        "offer_err_code": offer_err_code,
        "offer_err_code_hex": offer_err_code_hex,
        "offer_response": offer_ack,
        "history_response_received": history_response is not None,
        "history_accepted": history_accepted,
        "history_err_code": history_err_code,
        "history_err_code_hex": history_err_code_hex,
        "history_response": history_response,
        "offer_visible_in_history": history_accepted and len(matching_entries) > 0,
        "matching_history_entries": matching_entries,
        "http_request_count": http_requests,
        "action_started": action_started,
        "observed_upgrade_states": observed_upgrade_states,
        "forbidden_commands_sent": [],
        "output_dir": str(output_dir),
    }
    summary_path.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print(compact_json(summary))

    if error:
        return 1
    if not offer_accepted or not history_accepted:
        return 5
    return 0


def monitor_command(duration: float, output_dir: Path) -> int:
    output_dir.mkdir(parents=True, exist_ok=False)
    raw_path = output_dir / "reports.jsonl"
    upgrade_path = output_dir / "upgrade-events.jsonl"
    summary_path = output_dir / "summary.json"

    message_count = 0
    upgrade_count = 0
    resolved_upgrade: dict[str, Any] = {}
    upgrade_started = False
    terminal_result: str | None = None
    last_display_key: tuple[Any, ...] | None = None
    first_upgrade_timestamp: str | None = None
    final_upgrade_timestamp: str | None = None
    terminal_event = threading.Event()
    lock = threading.Lock()

    def phase_name(state: dict[str, Any]) -> str:
        message = str(state.get("message", "")).lower()
        module = str(state.get("module", "")).lower()
        status = str(state.get("status", "")).upper()

        if status == "UPGRADE_SUCCESS":
            return "Update successful"
        if "save image" in message:
            return "Finalizing"
        if "reboot" in message:
            return "Rebooting"
        if module == "th":
            return "Updating toolhead"
        if module == "mc":
            return "Updating motion controller"
        if module == "esp32":
            return "Updating AP/ESP32"
        if module == "ota":
            return "Preparing package"
        if status == "START":
            return "Starting update"
        return "Firmware update"

    def normalized_error_code(value: Any) -> int:
        try:
            return int(value)
        except (TypeError, ValueError):
            return 0

    def on_state(message: dict[str, Any]) -> None:
        nonlocal message_count
        nonlocal upgrade_count
        nonlocal upgrade_started
        nonlocal terminal_result
        nonlocal last_display_key
        nonlocal first_upgrade_timestamp
        nonlocal final_upgrade_timestamp

        observed_at = timestamp()
        record = {"timestamp": observed_at, "message": message}
        print_state = message.get("print") if isinstance(message, dict) else None
        upgrade_delta = (
            print_state.get("upgrade_state")
            if isinstance(print_state, dict)
            else None
        )

        with lock:
            with raw_path.open("a", encoding="utf-8", newline="\n") as handle:
                handle.write(compact_json(record) + "\n")
            message_count += 1

            if not isinstance(upgrade_delta, dict):
                return

            resolved_upgrade.update(upgrade_delta)
            upgrade_count += 1
            final_upgrade_timestamp = observed_at
            if first_upgrade_timestamp is None:
                first_upgrade_timestamp = observed_at

            resolved_record = {
                "timestamp": observed_at,
                "delta": upgrade_delta,
                "resolved": dict(resolved_upgrade),
            }
            with upgrade_path.open("a", encoding="utf-8", newline="\n") as handle:
                handle.write(compact_json(resolved_record) + "\n")

            status = str(resolved_upgrade.get("status", "")).upper()
            progress = str(resolved_upgrade.get("progress", ""))
            module = str(resolved_upgrade.get("module", ""))
            message_text = str(resolved_upgrade.get("message", ""))
            err_code = normalized_error_code(
                resolved_upgrade.get("err_code", 0)
            )

            if (
                status in {"START", "INSTALLING"}
                or (
                    progress not in {"", "0", "100"}
                    and message_text != ""
                )
            ):
                upgrade_started = True

            display_key = (
                phase_name(resolved_upgrade),
                progress,
                module,
                status,
                message_text,
                err_code,
            )
            if display_key != last_display_key:
                progress_text = f"{progress}%" if progress else "-"
                print(
                    f"{observed_at} | {display_key[0]} | "
                    f"Overall {progress_text} | "
                    f"Module {module or '-'} | "
                    f"{message_text or status or '-'}",
                    flush=True,
                )
                last_display_key = display_key

            if upgrade_started and status == "UPGRADE_SUCCESS" and err_code == 0:
                terminal_result = "success"
                terminal_event.set()
            elif upgrade_started and (
                err_code != 0
                or "FAIL" in status
                or "ERROR" in status
            ):
                terminal_result = "failure"
                terminal_event.set()

    client = X2DClient(Creds.resolve_default(), on_state=on_state)
    error: str | None = None
    started = time.monotonic()

    try:
        client.connect(timeout=10)
        print(
            f"{timestamp()} | Monitor connected; waiting for firmware activity.",
            flush=True,
        )
        deadline = started + duration
        while time.monotonic() < deadline and not terminal_event.is_set():
            time.sleep(0.2)
    except KeyboardInterrupt:
        terminal_result = terminal_result or "canceled"
    except Exception as exc:
        error = f"{type(exc).__name__}: {exc}"
    finally:
        try:
            client.disconnect()
        except Exception:
            pass

    if terminal_result is None:
        terminal_result = "timeout" if not error else "error"

    summary = {
        "operation": "firmware_monitor",
        "timestamp": timestamp(),
        "requested_duration_seconds": duration,
        "actual_duration_seconds": round(time.monotonic() - started, 3),
        "report_messages": message_count,
        "upgrade_events": upgrade_count,
        "upgrade_started": upgrade_started,
        "terminal_result": terminal_result,
        "first_upgrade_timestamp": first_upgrade_timestamp,
        "final_upgrade_timestamp": final_upgrade_timestamp,
        "final_upgrade_state": resolved_upgrade,
        "error": error,
        "output_dir": str(output_dir),
    }
    summary_path.write_text(
        json.dumps(summary, indent=2) + "\n",
        encoding="utf-8",
    )
    print("SUMMARY_JSON=" + compact_json(summary), flush=True)
    return 1 if error else 0

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="operation", required=True)

    status_parser = subparsers.add_parser("status")
    status_parser.add_argument("--timeout", type=float, default=8.0)

    send_parser = subparsers.add_parser("send")
    send_parser.add_argument("--payload-base64", required=True)
    send_parser.add_argument("--timeout", type=float, default=8.0)

    inspect_parser = subparsers.add_parser("inspect-package")
    inspect_parser.add_argument("--package-path", required=True)

    stage_parser = subparsers.add_parser("stage-package")
    stage_parser.add_argument("--package-path", required=True)
    stage_parser.add_argument("--destination-root", required=True)
    stage_parser.add_argument("--output-dir", required=True)

    probe_parser = subparsers.add_parser("offer-probe")
    probe_parser.add_argument("--package-path", required=True)
    probe_parser.add_argument("--printer-ip", required=True)
    probe_parser.add_argument("--expected-version", required=True)
    probe_parser.add_argument("--offer-sequence", required=True)
    probe_parser.add_argument("--history-sequence", required=True)
    probe_parser.add_argument("--output-dir", required=True)
    probe_parser.add_argument("--timeout", type=float, default=12.0)

    monitor_parser = subparsers.add_parser("monitor")
    monitor_parser.add_argument("--duration", type=float, default=900.0)
    monitor_parser.add_argument("--output-dir", required=True)

    return parser


def main() -> int:
    args = build_parser().parse_args()

    if args.operation == "status":
        return status_command(args.timeout)

    if args.operation == "send":
        return send_command(args.payload_base64, args.timeout)

    if args.operation == "inspect-package":
        try:
            inspection = inspect_offline_package(Path(args.package_path))
            print(compact_json(serializable_inspection(inspection)))
            return 0
        except Exception as exc:
            print(f"{type(exc).__name__}: {exc}", file=sys.stderr)
            return 1

    if args.operation == "stage-package":
        return stage_package_command(
            package_path=Path(args.package_path),
            destination_root=Path(args.destination_root),
            output_dir=Path(args.output_dir),
        )

    if args.operation == "offer-probe":
        return offer_probe_command(
            package_path=Path(args.package_path),
            printer_ip=args.printer_ip,
            expected_version=args.expected_version,
            offer_sequence=args.offer_sequence,
            history_sequence=args.history_sequence,
            output_dir=Path(args.output_dir),
            timeout=args.timeout,
        )

    if args.operation == "monitor":
        return monitor_command(args.duration, Path(args.output_dir))

    return 1


if __name__ == "__main__":
    raise SystemExit(main())
