#requires -Version 5.1
[CmdletBinding()]
param(
    [string]$InstallDirectory = "$env:LOCALAPPDATA\HotFetched\A1Mini-Agent",
    [switch]$NoStartup
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$sourceAgent = Join-Path $PSScriptRoot 'HotFetched-A1Mini-Agent.py'
$sourceController = Join-Path $PSScriptRoot 'A1Mini-Control-v6.4.2.ps1'
$sourceBridge = Join-Path $PSScriptRoot 'A1Mini-Bridge-v6.4.2.py'

foreach ($required in @($sourceAgent, $sourceController, $sourceBridge)) {
    if (-not (Test-Path -LiteralPath $required -PathType Leaf)) {
        throw "Required file not found: $required"
    }
}

New-Item -ItemType Directory -Path $InstallDirectory -Force | Out-Null

$existingPython = 'C:\tmp\beambam-win\Scripts\python.exe'
$pythonExe = $null

if (Test-Path -LiteralPath $existingPython -PathType Leaf) {
    try {
        & $existingPython -c "import beambam; print(beambam.__version__)" | Out-Null
        if ($LASTEXITCODE -eq 0) {
            $pythonExe = $existingPython
        }
    }
    catch {
        $pythonExe = $null
    }
}

if ($null -eq $pythonExe) {
    if (-not (Get-Command py.exe -ErrorAction SilentlyContinue)) {
        throw 'Python launcher py.exe was not found. Install Python 3.10 or later from python.org.'
    }

    $runtime = Join-Path $InstallDirectory 'runtime'
    $pythonExe = Join-Path $runtime 'Scripts\python.exe'

    if (-not (Test-Path -LiteralPath $pythonExe -PathType Leaf)) {
        Write-Host "Creating the local agent Python environment..."
        & py.exe -3.10 -m venv $runtime
        if ($LASTEXITCODE -ne 0) {
            & py.exe -3 -m venv $runtime
        }
        if ($LASTEXITCODE -ne 0) {
            throw 'Could not create the local Python environment.'
        }
    }

    $installed = ''
    try {
        $installed = (& $pythonExe -c "import beambam; print(beambam.__version__)" 2>$null | Out-String).Trim()
    }
    catch {
        $installed = ''
    }

    if ($installed -ne '1.5.1') {
        Write-Host 'Installing beambam 1.5.1...'
        & $pythonExe -m pip install "beambam==1.5.1"
        if ($LASTEXITCODE -ne 0) {
            throw 'Could not install beambam 1.5.1.'
        }
    }
}

Copy-Item -LiteralPath $sourceAgent -Destination (Join-Path $InstallDirectory 'HotFetched-A1Mini-Agent.py') -Force
Copy-Item -LiteralPath $sourceController -Destination (Join-Path $InstallDirectory 'A1Mini-Control-v6.4.2.ps1') -Force
Copy-Item -LiteralPath $sourceBridge -Destination (Join-Path $InstallDirectory 'A1Mini-Bridge-v6.4.2.py') -Force

$config = [ordered]@{
    version = 1
    python_exe = $pythonExe
    installed_utc = [DateTime]::UtcNow.ToString('o')
}
[System.IO.File]::WriteAllText(
    (Join-Path $InstallDirectory 'agent-config.json'),
    ($config | ConvertTo-Json -Depth 3),
    [System.Text.UTF8Encoding]::new($false)
)

$startScript = @'
#requires -Version 5.1
$ErrorActionPreference = 'Stop'
$installDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$config = Get-Content -LiteralPath (Join-Path $installDir 'agent-config.json') -Raw | ConvertFrom-Json
$python = [string]$config.python_exe
$pythonw = Join-Path (Split-Path -Parent $python) 'pythonw.exe'
if (-not (Test-Path -LiteralPath $pythonw -PathType Leaf)) { $pythonw = $python }
$agent = Join-Path $installDir 'HotFetched-A1Mini-Agent.py'

$connection = Get-NetTCPConnection -LocalAddress 127.0.0.1 -LocalPort 47841 -State Listen -ErrorAction SilentlyContinue
if ($null -eq $connection) {
    Start-Process -FilePath $pythonw -ArgumentList @('"' + $agent + '"') -WorkingDirectory $installDir -WindowStyle Hidden
    Start-Sleep -Milliseconds 900
}
Start-Process 'http://127.0.0.1:47841/pairing'
'@
[System.IO.File]::WriteAllText(
    (Join-Path $InstallDirectory 'Start-HotFetched-A1Mini-Agent.ps1'),
    $startScript,
    [System.Text.UTF8Encoding]::new($false)
)

$stopScript = @'
#requires -Version 5.1
$installDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$pidPath = Join-Path $env:LOCALAPPDATA 'HotFetched\A1Mini-Agent\agent.pid'
if (-not (Test-Path -LiteralPath $pidPath)) {
    Write-Host 'Agent PID file not found.'
    exit 0
}
$agentPid = [int](Get-Content -LiteralPath $pidPath -Raw)
$process = Get-CimInstance Win32_Process -Filter "ProcessId=$agentPid" -ErrorAction SilentlyContinue
if ($null -ne $process -and [string]$process.CommandLine -match 'HotFetched-A1Mini-Agent\.py') {
    Stop-Process -Id $agentPid -Force
    Write-Host 'HotFetched A1 Mini Agent stopped.'
}
else {
    Write-Warning 'PID did not belong to the HotFetched A1 Mini Agent.'
}
'@
[System.IO.File]::WriteAllText(
    (Join-Path $InstallDirectory 'Stop-HotFetched-A1Mini-Agent.ps1'),
    $stopScript,
    [System.Text.UTF8Encoding]::new($false)
)

$shell = New-Object -ComObject WScript.Shell
$desktop = [Environment]::GetFolderPath('Desktop')

function New-AgentShortcut {
    param(
        [string]$Path,
        [string]$Script,
        [string]$Description
    )
    $shortcut = $shell.CreateShortcut($Path)
    $shortcut.TargetPath = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
    $shortcut.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$Script`""
    $shortcut.WorkingDirectory = $InstallDirectory
    $shortcut.Description = $Description
    $shortcut.Save()
}

$startInstalled = Join-Path $InstallDirectory 'Start-HotFetched-A1Mini-Agent.ps1'
New-AgentShortcut `
    -Path (Join-Path $desktop 'HotFetched A1 Mini Agent.lnk') `
    -Script $startInstalled `
    -Description 'Start the HotFetched A1 Mini local agent and show its pairing code'

if (-not $NoStartup) {
    $startup = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Startup'
    New-Item -ItemType Directory -Path $startup -Force | Out-Null
    New-AgentShortcut `
        -Path (Join-Path $startup 'HotFetched A1 Mini Agent.lnk') `
        -Script $startInstalled `
        -Description 'Start the HotFetched A1 Mini local agent'
}

Write-Host ''
Write-Host "Installed HotFetched A1 Mini Agent to:"
Write-Host "  $InstallDirectory"
Write-Host "Python:"
Write-Host "  $pythonExe"
Write-Host ''
Write-Host 'The agent listens only on 127.0.0.1:47841.'
Write-Host 'No Windows Firewall rule is required.'

& $startInstalled
