#requires -Version 5.1
# A1Mini-Control v6.4.2
# Windows-native Bambu Lab A1 Mini controller using beambam signed MQTT at QoS 0.
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true, Position = 0)]
    [ValidateSet(
        'setup',
        'clear-credentials',
        'doctor',
        'status',
        'version',
        'firmware-history',
        'deploy-preflight',
        'firmware-inspect',
        'firmware-stage-sd',
        'firmware-workflow',
        'firmware-offer-probe',
        'firmware-offer-clear',
        'firmware-monitor',
        'firmware-verify',
        'watch',
        'led',
        'home',
        'jog',
        'pause',
        'resume',
        'stop',
        'set-temp',
        'fan',
        'all-off'
    )]
    [string]$Command,

    [Parameter(Position = 1)]
    [string]$Arg1,

    [Parameter(Position = 2)]
    [string]$Arg2,

    [int]$Feed,

    [ValidateRange(0, 7)]
    [int]$Index = 0,

    [ValidateRange(1, 60)]
    [int]$Timeout = 8,

    [ValidateRange(1, 60)]
    [int]$Interval = 3,

    [ValidateRange(10, 3600)]
    [int]$Duration = 900,

    [string]$PackagePath,

    [string]$SdDrive,

    [switch]$ConfirmSdStage,

    [switch]$AllowFixedDrive,

    [switch]$ConfirmFirmwareOfferProbe,

    [switch]$ConfirmMotion,

    [switch]$ConfirmPrintControl,

    [switch]$ConfirmHeat,

    [switch]$ConfirmAllOff,

    [switch]$Raw,

    [string]$Ip,

    [string]$Serial,

    [string]$PythonExe = 'C:\tmp\beambam-win\Scripts\python.exe',

    [string]$DataDir
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($DataDir)) {
    $DataDir = Join-Path $env:LOCALAPPDATA 'HotFetched\A1Mini-Control'
}

$ConfigPath = Join-Path $DataDir 'credentials.json'
$SequencePath = Join-Path $DataDir 'sequence.txt'
$BridgePath = Join-Path $PSScriptRoot 'A1Mini-Bridge-v6.4.2.py'

function Ensure-A1DataDirectory {
    if (-not (Test-Path -LiteralPath $DataDir -PathType Container)) {
        New-Item -ItemType Directory -Path $DataDir -Force | Out-Null
    }
}

function Protect-A1CredentialFile {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    # The LAN code is already encrypted with Windows DPAPI. Restricting the
    # file ACL is an additional best-effort layer and is intentionally
    # non-fatal because localized/domain account names can make icacls vary.
    try {
        $identity = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
        & icacls.exe $Path /inheritance:r /grant:r "${identity}:(F)" | Out-Null
    }
    catch {
        Write-Verbose "Could not tighten credential ACL: $($_.Exception.Message)"
    }
}

function Save-A1Credentials {
    param(
        [Parameter(Mandatory = $true)]
        [string]$PrinterIp,

        [Parameter(Mandatory = $true)]
        [string]$PrinterSerial,

        [Parameter(Mandatory = $true)]
        [string]$AccessCode
    )

    Ensure-A1DataDirectory

    $secure = ConvertTo-SecureString $AccessCode -AsPlainText -Force
    $encryptedCode = ConvertFrom-SecureString $secure

    $config = [ordered]@{
        version      = 1
        ip           = $PrinterIp
        serial       = $PrinterSerial
        code_dpapi   = $encryptedCode
        saved_utc    = [DateTime]::UtcNow.ToString('o')
    }

    $json = $config | ConvertTo-Json -Depth 4
    [System.IO.File]::WriteAllText(
        $ConfigPath,
        $json,
        [System.Text.UTF8Encoding]::new($false)
    )
    Protect-A1CredentialFile -Path $ConfigPath
}

function Read-A1SavedCredentials {
    if (-not (Test-Path -LiteralPath $ConfigPath -PathType Leaf)) {
        return $null
    }

    try {
        $config = Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json
        $secure = ConvertTo-SecureString ([string]$config.code_dpapi)
        $code = [System.Net.NetworkCredential]::new('', $secure).Password

        if ([string]::IsNullOrWhiteSpace([string]$config.ip) -or
            [string]::IsNullOrWhiteSpace([string]$config.serial) -or
            [string]::IsNullOrWhiteSpace($code)) {
            throw 'Stored credential record is incomplete.'
        }

        return [pscustomobject]@{
            Ip     = [string]$config.ip
            Serial = [string]$config.serial
            Code   = $code
        }
    }
    catch {
        throw "Could not decrypt saved A1 Mini credentials. Run 'clear-credentials', then 'setup'. Details: $($_.Exception.Message)"
    }
}

function Resolve-A1Credentials {
    param(
        [string]$RequestedIp,
        [string]$RequestedSerial,
        [switch]$ForcePrompt
    )

    $saved = Read-A1SavedCredentials

    $resolvedIp = $RequestedIp
    if ([string]::IsNullOrWhiteSpace($resolvedIp) -and -not $ForcePrompt) {
        $resolvedIp = $env:X2D_IP
    }
    if ([string]::IsNullOrWhiteSpace($resolvedIp) -and $null -ne $saved) {
        $resolvedIp = $saved.Ip
    }

    $resolvedSerial = $RequestedSerial
    if ([string]::IsNullOrWhiteSpace($resolvedSerial) -and -not $ForcePrompt) {
        $resolvedSerial = $env:X2D_SERIAL
    }
    if ([string]::IsNullOrWhiteSpace($resolvedSerial) -and $null -ne $saved) {
        $resolvedSerial = $saved.Serial
    }

    $resolvedCode = $null
    if (-not $ForcePrompt) {
        $resolvedCode = $env:X2D_CODE
    }
    if ([string]::IsNullOrWhiteSpace($resolvedCode) -and $null -ne $saved) {
        $resolvedCode = $saved.Code
    }

    if ([string]::IsNullOrWhiteSpace($resolvedIp)) {
        $resolvedIp = Read-Host 'Printer IP'
    }
    if ([string]::IsNullOrWhiteSpace($resolvedSerial)) {
        $resolvedSerial = Read-Host 'Printer serial'
    }
    if ([string]::IsNullOrWhiteSpace($resolvedCode)) {
        $secureCode = Read-Host 'LAN access code' -AsSecureString
        $resolvedCode = [System.Net.NetworkCredential]::new('', $secureCode).Password
    }

    if ([string]::IsNullOrWhiteSpace($resolvedIp) -or
        [string]::IsNullOrWhiteSpace($resolvedSerial) -or
        [string]::IsNullOrWhiteSpace($resolvedCode)) {
        throw 'Printer IP, serial, and LAN access code are required.'
    }

    return [pscustomobject]@{
        Ip     = $resolvedIp.Trim()
        Serial = $resolvedSerial.Trim()
        Code   = $resolvedCode
    }
}

function Invoke-WithA1Environment {
    param(
        [Parameter(Mandatory = $true)]
        [psobject]$Credentials,

        [Parameter(Mandatory = $true)]
        [scriptblock]$Action
    )

    $oldIp = $env:X2D_IP
    $oldSerial = $env:X2D_SERIAL
    $oldCode = $env:X2D_CODE

    try {
        $env:X2D_IP = $Credentials.Ip
        $env:X2D_SERIAL = $Credentials.Serial
        $env:X2D_CODE = $Credentials.Code
        & $Action
    }
    finally {
        if ($null -eq $oldIp) {
            Remove-Item Env:X2D_IP -ErrorAction SilentlyContinue
        }
        else {
            $env:X2D_IP = $oldIp
        }

        if ($null -eq $oldSerial) {
            Remove-Item Env:X2D_SERIAL -ErrorAction SilentlyContinue
        }
        else {
            $env:X2D_SERIAL = $oldSerial
        }

        if ($null -eq $oldCode) {
            Remove-Item Env:X2D_CODE -ErrorAction SilentlyContinue
        }
        else {
            $env:X2D_CODE = $oldCode
        }
    }
}

function Test-A1Runtime {
    if (-not (Test-Path -LiteralPath $PythonExe -PathType Leaf)) {
        throw "Python environment not found: $PythonExe"
    }
    if (-not (Test-Path -LiteralPath $BridgePath -PathType Leaf)) {
        throw "Python bridge helper not found: $BridgePath"
    }

    $compile = Invoke-A1Python -Arguments @('-m', 'py_compile', $BridgePath)
    if ($compile.ExitCode -ne 0) {
        throw "Python bridge helper failed syntax validation: $($compile.Text)"
    }

    $version = Invoke-A1Python -Arguments @(
        '-c',
        'import beambam; print(beambam.__version__)'
    )
    if ($version.ExitCode -ne 0) {
        throw "Could not import beambam from '$PythonExe': $($version.Text)"
    }

    return $version.Text
}

function Get-NextA1SequenceId {
    Ensure-A1DataDirectory

    $mutex = [System.Threading.Mutex]::new($false, 'Local\HotFetched.A1MiniControl.Sequence')
    $locked = $false

    try {
        $locked = $mutex.WaitOne(5000)
        if (-not $locked) {
            throw 'Timed out waiting for the sequence-ID lock.'
        }

        $current = [int64]0
        if (Test-Path -LiteralPath $SequencePath -PathType Leaf) {
            $stored = (Get-Content -LiteralPath $SequencePath -Raw).Trim()
            [void][int64]::TryParse(
                $stored,
                [System.Globalization.NumberStyles]::Integer,
                [System.Globalization.CultureInfo]::InvariantCulture,
                [ref]$current
            )
        }

        # Keep IDs inside signed 32-bit range, matching the small decimal IDs
        # used by Bambu Studio while remaining unique across script launches.
        $now = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
        $next = [math]::Max($now, $current + 1)
        if ($next -ge 2147483000) {
            $next = 100000
        }

        [System.IO.File]::WriteAllText(
            $SequencePath,
            $next.ToString([System.Globalization.CultureInfo]::InvariantCulture),
            [System.Text.UTF8Encoding]::new($false)
        )

        return $next.ToString([System.Globalization.CultureInfo]::InvariantCulture)
    }
    finally {
        if ($locked) {
            [void]$mutex.ReleaseMutex()
        }
        $mutex.Dispose()
    }
}

function New-A1PrintPayload {
    param(
        [Parameter(Mandatory = $true)]
        [string]$CommandName,

        [System.Collections.IDictionary]$Extra
    )

    $body = [ordered]@{
        command     = $CommandName
        sequence_id = Get-NextA1SequenceId
    }

    if ($null -ne $Extra) {
        foreach ($key in $Extra.Keys) {
            $body[$key] = $Extra[$key]
        }
    }

    return [ordered]@{ print = $body }
}

function New-A1InfoPayload {
    param(
        [Parameter(Mandatory = $true)]
        [string]$CommandName,

        [System.Collections.IDictionary]$Extra
    )

    $body = [ordered]@{
        command     = $CommandName
        sequence_id = Get-NextA1SequenceId
    }

    if ($null -ne $Extra) {
        foreach ($key in $Extra.Keys) {
            $body[$key] = $Extra[$key]
        }
    }

    return [ordered]@{ info = $body }
}

function New-A1UpgradePayload {
    param(
        [Parameter(Mandatory = $true)]
        [string]$CommandName,

        [System.Collections.IDictionary]$Extra
    )

    $body = [ordered]@{
        command     = $CommandName
        sequence_id = Get-NextA1SequenceId
    }

    if ($null -ne $Extra) {
        foreach ($key in $Extra.Keys) {
            $body[$key] = $Extra[$key]
        }
    }

    return [ordered]@{ upgrade = $body }
}

function New-A1SystemPayload {
    param(
        [Parameter(Mandatory = $true)]
        [string]$CommandName,

        [System.Collections.IDictionary]$Extra
    )

    $body = [ordered]@{
        command     = $CommandName
        sequence_id = Get-NextA1SequenceId
    }

    if ($null -ne $Extra) {
        foreach ($key in $Extra.Keys) {
            $body[$key] = $Extra[$key]
        }
    }

    return [ordered]@{ system = $body }
}

function Invoke-A1Python {
    param(
        [Parameter(Mandatory = $true)]
        [string[]]$Arguments
    )

    # Windows PowerShell 5.1 converts native stderr into PowerShell error
    # records. Temporarily keep those non-terminating so we can capture the
    # complete Python diagnostic and evaluate the actual process exit code.
    $savedPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        $output = & $PythonExe @Arguments 2>&1
        $exitCode = $LASTEXITCODE
    }
    finally {
        $ErrorActionPreference = $savedPreference
    }

    return [pscustomobject]@{
        ExitCode = $exitCode
        Text     = ($output | Out-String).Trim()
    }
}

function Get-A1State {
    $run = Invoke-A1Python -Arguments @(
        $BridgePath,
        'status',
        '--timeout',
        $Timeout.ToString([System.Globalization.CultureInfo]::InvariantCulture)
    )

    if ($run.ExitCode -eq 130) {
        throw [System.Management.Automation.PipelineStoppedException]::new()
    }
    if ($run.ExitCode -ne 0) {
        throw "A1 Mini status request failed with exit code $($run.ExitCode). $($run.Text)"
    }
    if ([string]::IsNullOrWhiteSpace($run.Text)) {
        throw 'A1 Mini status request returned no data.'
    }

    try {
        return $run.Text | ConvertFrom-Json
    }
    catch {
        throw "Could not parse A1 Mini status JSON: $($_.Exception.Message)`n$($run.Text)"
    }
}

function Invoke-A1Payload {
    param(
        [Parameter(Mandatory = $true)]
        [System.Collections.IDictionary]$Payload
    )

    $payloadJson = $Payload | ConvertTo-Json -Depth 12 -Compress
    $payloadBytes = [System.Text.Encoding]::UTF8.GetBytes($payloadJson)
    $payloadBase64 = [Convert]::ToBase64String($payloadBytes)

    $run = Invoke-A1Python -Arguments @(
        $BridgePath,
        'send',
        '--payload-base64',
        $payloadBase64,
        '--timeout',
        $Timeout.ToString([System.Globalization.CultureInfo]::InvariantCulture)
    )

    if ($run.ExitCode -eq 130) {
        throw [System.Management.Automation.PipelineStoppedException]::new()
    }

    $ack = $null
    if (-not [string]::IsNullOrWhiteSpace($run.Text)) {
        try {
            $ack = $run.Text | ConvertFrom-Json
        }
        catch {
            if ($run.ExitCode -ne 0) {
                throw "A1 Mini command failed with exit code $($run.ExitCode).`n$($run.Text)"
            }
            throw "Could not parse acknowledgement JSON.`n$($run.Text)"
        }
    }

    if ($run.ExitCode -eq 3) {
        throw "Printer did not acknowledge $($ack.family).$($ack.command) sequence $($ack.sequence_id) within $Timeout second(s)."
    }
    if ($run.ExitCode -eq 4) {
        $errorDetail = if ($null -ne $ack.err_code) {
            "err_code=$($ack.err_code) ($($ack.err_code_hex))"
        }
        else {
            "result=$($ack.result), reason=$($ack.reason)"
        }
        throw "Printer rejected $($ack.family).$($ack.command) sequence $($ack.sequence_id): $errorDetail"
    }
    if ($run.ExitCode -ne 0) {
        throw "A1 Mini command failed with exit code $($run.ExitCode).`n$($run.Text)"
    }
    if ($null -eq $ack -or -not $ack.acknowledged) {
        throw 'A1 Mini command completed without a valid acknowledgement record.'
    }

    $resultText = if ($null -ne $ack.err_code -and [int64]$ack.err_code -ne 0) {
        "rejected err_code=$($ack.err_code) ($($ack.err_code_hex))"
    }
    elseif ([string]::IsNullOrWhiteSpace([string]$ack.result)) {
        'acknowledged'
    }
    else {
        [string]$ack.result
    }

    Write-Host "ACK $($ack.family).$($ack.command) | seq $($ack.sequence_id) | $resultText"
    return $ack
}

function Get-ObjectProperty {
    param(
        [AllowNull()]
        [object]$Object,

        [Parameter(Mandatory = $true)]
        [string]$Name,

        [object]$Default = '-'
    )

    if ($null -eq $Object) {
        return $Default
    }

    $property = $Object.PSObject.Properties[$Name]
    if ($null -eq $property -or $null -eq $property.Value) {
        return $Default
    }

    return $property.Value
}

function Convert-FanTelemetryToDisplay {
    param(
        [AllowNull()]
        [object]$RawValue
    )

    if ($null -eq $RawValue) {
        return '-'
    }

    $raw = 0
    if (-not [int]::TryParse(
        [string]$RawValue,
        [System.Globalization.NumberStyles]::Integer,
        [System.Globalization.CultureInfo]::InvariantCulture,
        [ref]$raw
    )) {
        return [string]$RawValue
    }

    $percent = [int]([math]::Round((($raw / 15.0) * 10.0), 0) * 10)
    $percent = [math]::Max(0, [math]::Min(100, $percent))
    return "$percent% (raw $raw)"
}

function Get-A1LightMode {
    param(
        [AllowNull()]
        [object]$PrintState
    )

    $lights = Get-ObjectProperty -Object $PrintState -Name 'lights_report' -Default @()
    foreach ($light in @($lights)) {
        if ((Get-ObjectProperty -Object $light -Name 'node') -eq 'chamber_light') {
            return [string](Get-ObjectProperty -Object $light -Name 'mode')
        }
    }

    return '-'
}

function Format-A1StateLine {
    param(
        [Parameter(Mandatory = $true)]
        [object]$State
    )

    $print = Get-ObjectProperty -Object $State -Name 'print' -Default $null
    $gcodeState = [string](Get-ObjectProperty -Object $print -Name 'gcode_state')
    $printType = [string](Get-ObjectProperty -Object $print -Name 'print_type')
    $printError = Get-ObjectProperty -Object $print -Name 'print_error' -Default 0

    $displayState = $gcodeState
    if ($printType -eq 'idle' -and [int64]$printError -eq 0 -and $gcodeState -eq 'FAILED') {
        $displayState = 'IDLE'
    }

    $fanRaw = Get-ObjectProperty -Object $print -Name 'cooling_fan_speed' -Default $null
    $fanDisplay = Convert-FanTelemetryToDisplay -RawValue $fanRaw
    $lightMode = Get-A1LightMode -PrintState $print

    return '{0:HH:mm:ss} | State {1} | Progress {2}% | Nozzle {3}/{4} C | Bed {5}/{6} C | Part fan {7} | Wi-Fi {8} | Light {9}' -f `
        (Get-Date),
        $displayState,
        (Get-ObjectProperty -Object $print -Name 'mc_percent' -Default 0),
        (Get-ObjectProperty -Object $print -Name 'nozzle_temper'),
        (Get-ObjectProperty -Object $print -Name 'nozzle_target_temper'),
        (Get-ObjectProperty -Object $print -Name 'bed_temper'),
        (Get-ObjectProperty -Object $print -Name 'bed_target_temper'),
        $fanDisplay,
        (Get-ObjectProperty -Object $print -Name 'wifi_signal'),
        $lightMode
}

function Wait-A1Condition {
    param(
        [Parameter(Mandatory = $true)]
        [scriptblock]$Condition,

        [Parameter(Mandatory = $true)]
        [string]$Description
    )

    $deadline = [DateTime]::UtcNow.AddSeconds($Timeout)
    $lastState = $null

    do {
        $lastState = Get-A1State
        if (& $Condition $lastState) {
            Write-Host "Verified: $Description"
            return $lastState
        }

        Start-Sleep -Milliseconds 750
    }
    while ([DateTime]::UtcNow -lt $deadline)

    throw "Command was acknowledged, but status did not verify '$Description' within $Timeout second(s). Last state: $(Format-A1StateLine -State $lastState)"
}

function Get-A1VersionReport {
    $payload = New-A1InfoPayload -CommandName 'get_version' -Extra ([ordered]@{})
    $ack = Invoke-A1Payload -Payload $payload
    $info = Get-ObjectProperty -Object $ack.response -Name 'info' -Default $null
    $modules = @(Get-ObjectProperty -Object $info -Name 'module' -Default @())

    $ota = $modules | Where-Object { (Get-ObjectProperty -Object $_ -Name 'name') -eq 'ota' } | Select-Object -First 1
    $version = if ($null -ne $ota) {
        [string](Get-ObjectProperty -Object $ota -Name 'sw_ver')
    }
    else {
        '-'
    }

    return [pscustomobject]@{
        Version = $version
        Modules = $modules
        Raw     = $ack.response
    }
}

function Get-A1FirmwareHistoryReport {
    $payload = New-A1UpgradePayload -CommandName 'get_history' -Extra ([ordered]@{})
    $ack = Invoke-A1Payload -Payload $payload
    $upgrade = Get-ObjectProperty -Object $ack.response -Name 'upgrade' -Default $null
    $optional = @(Get-ObjectProperty -Object $upgrade -Name 'firmware_optional' -Default @())

    return [pscustomobject]@{
        FirmwareOptional = $optional
        Raw              = $ack.response
    }
}


function Get-A1OfflinePackageInspection {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "Offline package not found: $Path"
    }

    $run = Invoke-A1Python -Arguments @(
        $BridgePath,
        'inspect-package',
        '--package-path',
        (Resolve-Path -LiteralPath $Path).Path
    )
    if ($run.ExitCode -ne 0) {
        throw "Offline package inspection failed.`n$($run.Text)"
    }

    try {
        return $run.Text | ConvertFrom-Json
    }
    catch {
        throw "Could not parse offline package inspection JSON.`n$($run.Text)"
    }
}

function Get-A1PackageIntegrityRows {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Inspection
    )

    return @(
        [pscustomobject]@{ Check = 'ZIP integrity'; Pass = [bool]$Inspection.zip_integrity }
        [pscustomobject]@{ Check = 'Package-list BIMH inner digest'; Pass = [bool]$Inspection.package_list_inner_hash_valid }
        [pscustomobject]@{ Check = 'N1 manifest BIMH inner digest'; Pass = [bool]$Inspection.n1_manifest_inner_hash_valid }
        [pscustomobject]@{ Check = 'Package member SHA-256 chain'; Pass = [bool]$Inspection.package_hashes_valid }
        [pscustomobject]@{ Check = 'Component MD5 chain'; Pass = [bool]$Inspection.component_md5_valid }
        [pscustomobject]@{ Check = 'A1 Mini model N1'; Pass = ([string]$Inspection.model_name -eq 'N1') }
        [pscustomobject]@{
            Check = 'OTA versions agree'
            Pass = (
                -not [string]::IsNullOrWhiteSpace([string]$Inspection.version) -and
                [string]$Inspection.version -eq [string]$Inspection.package_list_ota_version
            )
        }
    )
}

function Assert-A1StageablePackage {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Inspection
    )

    $failed = @(Get-A1PackageIntegrityRows -Inspection $Inspection | Where-Object { -not $_.Pass })
    if ($failed.Count -gt 0) {
        throw "Firmware package failed $($failed.Count) integrity check(s)."
    }
}

function Show-A1OfflinePackageInspection {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Inspection
    )

    Write-Host "Package:      $($Inspection.package_filename)"
    Write-Host "Model:        $($Inspection.model_name)"
    Write-Host "OTA version:  $($Inspection.version)"
    Write-Host "Size:         $($Inspection.package_size) bytes"
    Write-Host "SHA-256:      $($Inspection.package_sha256)"
    Write-Host "Manifest:     $($Inspection.manifest_filename)"
    Write-Host ''

    Get-A1PackageIntegrityRows -Inspection $Inspection |
        Format-Table Check, Pass -AutoSize

    $targets = @(
        $Inspection.targets.PSObject.Properties |
            Sort-Object Name |
            ForEach-Object {
                [pscustomobject]@{
                    Target = $_.Name.ToUpperInvariant()
                    Version = [string]$_.Value
                }
            }
    )
    if ($targets.Count -gt 0) {
        Write-Host ''
        $targets | Format-Table Target, Version -AutoSize
    }

    Write-Warning 'HotFetched validates the package structure and internal digest/hash chain. The printer remains authoritative for the Bambu public-key signature.'
}

function Resolve-A1SdDriveInfo {
    param(
        [Parameter(Mandatory = $true)]
        [string]$RequestedDrive,

        [switch]$PermitFixedDrive
    )

    $deviceId = $RequestedDrive.Trim().TrimEnd('\')
    if ($deviceId -match '^[A-Za-z]$') {
        $deviceId = "$deviceId`:"
    }
    if ($deviceId -notmatch '^[A-Za-z]:$') {
        throw "Invalid SD drive '$RequestedDrive'. Specify only a drive letter such as E:."
    }

    $deviceId = $deviceId.ToUpperInvariant()
    $drive = Get-CimInstance Win32_LogicalDisk -Filter "DeviceID='$deviceId'"
    if ($null -eq $drive) {
        throw "Drive $deviceId is not mounted."
    }

    if ([int]$drive.DriveType -eq 2) {
        # Removable media: accepted.
    }
    elseif ([int]$drive.DriveType -eq 3 -and $PermitFixedDrive) {
        Write-Warning "Windows reports $deviceId as a fixed drive. -AllowFixedDrive was supplied; verify the drive letter carefully."
    }
    else {
        throw "Drive $deviceId is not reported as removable media. Use -AllowFixedDrive only when a known SD reader is reported as fixed."
    }

    if ([string]::IsNullOrWhiteSpace([string]$drive.FileSystem)) {
        throw "Drive $deviceId is not ready or has no mounted filesystem."
    }

    return [pscustomobject]@{
        DeviceId   = $deviceId
        Root        = "$deviceId\"
        DriveType   = [int]$drive.DriveType
        VolumeName  = [string]$drive.VolumeName
        FileSystem  = [string]$drive.FileSystem
        Size        = [uint64]$drive.Size
        FreeSpace   = [uint64]$drive.FreeSpace
    }
}

function Invoke-A1PackageStage {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Inspection,

        [Parameter(Mandatory = $true)]
        [object]$DriveInfo
    )

    Assert-A1StageablePackage -Inspection $Inspection
    Ensure-A1DataDirectory

    $stageRoot = Join-Path $DataDir 'firmware-staging'
    New-Item -ItemType Directory -Path $stageRoot -Force | Out-Null
    $stageDirectory = Join-Path $stageRoot (Get-Date -Format 'yyyyMMdd-HHmmss')

    $run = Invoke-A1Python -Arguments @(
        $BridgePath,
        'stage-package',
        '--package-path',
        (Resolve-Path -LiteralPath $PackagePath).Path,
        '--destination-root',
        $DriveInfo.Root,
        '--output-dir',
        $stageDirectory
    )

    if ($run.ExitCode -ne 0) {
        throw "SD-card firmware staging failed.`n$($run.Text)"
    }

    try {
        $summary = $run.Text | ConvertFrom-Json
    }
    catch {
        throw "Could not parse SD-card staging result.`n$($run.Text)"
    }

    if (-not [bool]$summary.hash_match) {
        throw 'The staged package did not pass final SHA-256 verification.'
    }

    Write-Host ''
    Write-Host "Stage result: $($summary.status)"
    Write-Host "SD target:    $($summary.destination_path)"
    Write-Host "SHA-256:      $($summary.destination_sha256)"
    Write-Host "Evidence:     $stageDirectory"

    return $summary
}

function Invoke-A1FirmwareMonitor {
    param(
        [Parameter(Mandatory = $true)]
        [int]$MonitorDuration
    )

    Ensure-A1DataDirectory
    $monitorRoot = Join-Path $DataDir 'firmware-monitors'
    New-Item -ItemType Directory -Path $monitorRoot -Force | Out-Null
    $monitorDirectory = Join-Path $monitorRoot (Get-Date -Format 'yyyyMMdd-HHmmss')

    Write-Host "Passive firmware monitor running for up to $MonitorDuration second(s)."
    Write-Host "Evidence directory: $monitorDirectory"
    Write-Host 'This monitor sends no printer control command.'
    Write-Host ''

    $savedPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = 'Continue'
        & $PythonExe $BridgePath `
            'monitor' `
            '--duration' $MonitorDuration `
            '--output-dir' $monitorDirectory 2>&1 |
            ForEach-Object { Write-Host ([string]$_) }
        $monitorExitCode = $LASTEXITCODE
    }
    finally {
        $ErrorActionPreference = $savedPreference
    }

    $summaryPath = Join-Path $monitorDirectory 'summary.json'
    if (-not (Test-Path -LiteralPath $summaryPath -PathType Leaf)) {
        throw "Firmware monitor produced no summary. Exit code: $monitorExitCode"
    }

    $summary = Get-Content -LiteralPath $summaryPath -Raw | ConvertFrom-Json
    Write-Host ''
    Write-Host "Reports captured: $($summary.report_messages)"
    Write-Host "Upgrade events:   $($summary.upgrade_events)"
    Write-Host "Upgrade started:  $($summary.upgrade_started)"
    Write-Host "Terminal result:  $($summary.terminal_result)"
    Write-Host "Evidence:         $monitorDirectory"

    if ($monitorExitCode -ne 0) {
        throw "Firmware monitor failed with exit code $monitorExitCode. $($summary.error)"
    }

    return $summary
}

function Invoke-A1FirmwareVerification {
    param(
        [AllowNull()]
        [object]$Inspection,

        [AllowNull()]
        [string]$ExpectedVersion,

        [Parameter(Mandatory = $true)]
        [psobject]$Credentials
    )

    $versionReport = Get-A1VersionReport
    $state = Get-A1State
    $print = Get-ObjectProperty -Object $state -Name 'print' -Default $null
    $upgradeState = Get-ObjectProperty -Object $print -Name 'upgrade_state' -Default $null

    $actualByHardware = @{}
    foreach ($module in @($versionReport.Modules)) {
        $hardware = [string](Get-ObjectProperty -Object $module -Name 'hw_ver' -Default '')
        if (-not [string]::IsNullOrWhiteSpace($hardware)) {
            $actualByHardware[$hardware.ToLowerInvariant()] = [string](Get-ObjectProperty -Object $module -Name 'sw_ver')
        }
    }

    $rows = @(
        [pscustomobject]@{
            Target = 'OTA'
            Expected = if (-not [string]::IsNullOrWhiteSpace($ExpectedVersion)) { $ExpectedVersion } else { '-' }
            Actual = [string]$versionReport.Version
            Pass = if (-not [string]::IsNullOrWhiteSpace($ExpectedVersion)) {
                [string]$versionReport.Version -eq $ExpectedVersion
            }
            else {
                $true
            }
        }
    )

    if ($null -ne $Inspection) {
        foreach ($hardware in @('ap05', 'mc02', 'th03')) {
            $expected = [string](Get-ObjectProperty -Object $Inspection.targets -Name $hardware -Default '-')
            $actual = if ($actualByHardware.ContainsKey($hardware)) {
                [string]$actualByHardware[$hardware]
            }
            else {
                '-'
            }

            $rows += [pscustomobject]@{
                Target = $hardware.ToUpperInvariant()
                Expected = $expected
                Actual = $actual
                Pass = ($expected -eq $actual)
            }
        }
    }

    $rows |
        Format-Table Target, Expected, Actual, Pass -AutoSize |
        Out-String |
        Write-Host
    $upgradeStatus = [string](Get-ObjectProperty -Object $upgradeState -Name 'status')
    Write-Host "Upgrade state: $upgradeStatus"

    Ensure-A1DataDirectory
    $verification = [ordered]@{
        timestamp_utc = [DateTime]::UtcNow.ToString('o')
        printer_ip = $Credentials.Ip
        ota_version = $versionReport.Version
        upgrade_status = $upgradeStatus
        package = $Inspection
        checks = $rows
    }
    $verificationPath = Join-Path $DataDir ("firmware-verification-{0}.json" -f (Get-Date -Format 'yyyyMMdd-HHmmss'))
    [System.IO.File]::WriteAllText(
        $verificationPath,
        ($verification | ConvertTo-Json -Depth 30),
        [System.Text.UTF8Encoding]::new($false)
    )
    Write-Host "Verification record: $verificationPath"

    $failedRows = @($rows | Where-Object { -not $_.Pass })
    if ($failedRows.Count -gt 0) {
        throw "Firmware verification failed $($failedRows.Count) comparison(s)."
    }

    return [pscustomobject]@{
        Passed = $true
        Rows = $rows
        UpgradeStatus = $upgradeStatus
        RecordPath = $verificationPath
    }
}


function Invoke-A1Main {
    if ($Command -eq 'clear-credentials') {
        if (Test-Path -LiteralPath $ConfigPath -PathType Leaf) {
            Remove-Item -LiteralPath $ConfigPath -Force
        }
        Remove-Item Env:X2D_IP -ErrorAction SilentlyContinue
        Remove-Item Env:X2D_SERIAL -ErrorAction SilentlyContinue
        Remove-Item Env:X2D_CODE -ErrorAction SilentlyContinue
        Write-Host "Removed saved credentials from $ConfigPath"
        return
    }

    $beambamVersion = Test-A1Runtime

    if ($Command -eq 'setup') {
    $credentials = Resolve-A1Credentials -RequestedIp $Ip -RequestedSerial $Serial
        Save-A1Credentials `
            -PrinterIp $credentials.Ip `
            -PrinterSerial $credentials.Serial `
            -AccessCode $credentials.Code

        Write-Host "Saved Windows-DPAPI-protected credentials to $ConfigPath"
        Write-Host "beambam $beambamVersion | Python $PythonExe"

        Invoke-WithA1Environment -Credentials $credentials -Action {
            $state = Get-A1State
            Write-Host (Format-A1StateLine -State $state)
        }
        return
    }

    if ($Command -eq 'firmware-inspect') {
        if ([string]::IsNullOrWhiteSpace($PackagePath)) {
            throw 'Usage: .\A1Mini-Control-v6.4.2.ps1 firmware-inspect -PackagePath OFFICIAL_OFFLINE_ZIP'
        }

        $inspection = Get-A1OfflinePackageInspection -Path $PackagePath
        Assert-A1StageablePackage -Inspection $inspection

        if ($Raw) {
            $inspection | ConvertTo-Json -Depth 30
        }
        else {
            Show-A1OfflinePackageInspection -Inspection $inspection
            Write-Host ''
            Write-Host 'Package integrity checks passed.'
        }
        return
    }

    if ($Command -eq 'firmware-stage-sd') {
        if (-not $ConfirmSdStage) {
            throw 'SD staging writes the selected firmware ZIP to the root of the selected drive. Rerun with -ConfirmSdStage.'
        }
        if ([string]::IsNullOrWhiteSpace($PackagePath)) {
            throw 'Usage: .\A1Mini-Control-v6.4.2.ps1 firmware-stage-sd -PackagePath OFFICIAL_OFFLINE_ZIP -SdDrive E: -ConfirmSdStage'
        }
        if ([string]::IsNullOrWhiteSpace($SdDrive)) {
            $candidates = @(
                Get-CimInstance Win32_LogicalDisk |
                    Where-Object { $_.DriveType -in @(2, 3) } |
                    Select-Object DeviceID, VolumeName, FileSystem, DriveType, Size, FreeSpace
            )
            if ($candidates.Count -gt 0) {
                $candidates | Format-Table -AutoSize
            }
            throw 'Specify the SD-card drive explicitly with -SdDrive E:.'
        }

        $inspection = Get-A1OfflinePackageInspection -Path $PackagePath
        Assert-A1StageablePackage -Inspection $inspection
        $driveInfo = Resolve-A1SdDriveInfo -RequestedDrive $SdDrive -PermitFixedDrive:$AllowFixedDrive

        Write-Host "Selected drive: $($driveInfo.DeviceId)"
        Write-Host "Volume label:   $($driveInfo.VolumeName)"
        Write-Host "Filesystem:     $($driveInfo.FileSystem)"
        Write-Host "Free space:     $($driveInfo.FreeSpace) bytes"
        Show-A1OfflinePackageInspection -Inspection $inspection

        [void](Invoke-A1PackageStage -Inspection $inspection -DriveInfo $driveInfo)
        Write-Host ''
        Write-Host 'SD staging completed and the copied ZIP matches the source SHA-256.'
        Write-Host 'Use Windows Safely Remove Hardware before removing the card.'
        return
    }


    $credentials = Resolve-A1Credentials -RequestedIp $Ip -RequestedSerial $Serial

    Invoke-WithA1Environment -Credentials $credentials -Action {
        if ($Command -eq 'doctor') {
            Write-Host "Python:   $PythonExe"
            Write-Host "beambam:  $beambamVersion"
            Write-Host "Printer:  $($credentials.Ip)"
            Write-Host "Serial:   $($credentials.Serial)"
            Write-Host "Secrets:  Windows DPAPI file $ConfigPath"
            $state = Get-A1State
            Write-Host "MQTT:     connected; QoS 0 state request succeeded"
            Write-Host (Format-A1StateLine -State $state)
            return
        }

        if ($Command -eq 'status') {
            $state = Get-A1State
            if ($Raw) {
                $state | ConvertTo-Json -Depth 20
            }
            else {
                Write-Host (Format-A1StateLine -State $state)
            }
            return
        }

        if ($Command -eq 'version') {
            $report = Get-A1VersionReport
            Write-Host "Printer OTA version: $($report.Version)"
            $report.Modules | Select-Object name, sw_ver, hw_ver, sn | Format-Table -AutoSize
            return
        }

        if ($Command -eq 'firmware-history') {
            $report = Get-A1FirmwareHistoryReport
            if ($report.FirmwareOptional.Count -eq 0) {
                Write-Host 'Printer returned no firmware history entries.'
            }
            else {
                $report.FirmwareOptional | ConvertTo-Json -Depth 20
            }
            return
        }

        if ($Command -eq 'deploy-preflight') {
            Write-Host 'Running read-only firmware deployment preflight...'

            $state = Get-A1State
            $print = Get-ObjectProperty -Object $state -Name 'print' -Default $null
            $upgradeState = Get-ObjectProperty -Object $print -Name 'upgrade_state' -Default $null

            $printType = [string](Get-ObjectProperty -Object $print -Name 'print_type')
            $printError = [int64](Get-ObjectProperty -Object $print -Name 'print_error' -Default -1)
            $nozzleTarget = [double](Get-ObjectProperty -Object $print -Name 'nozzle_target_temper' -Default -1)
            $bedTarget = [double](Get-ObjectProperty -Object $print -Name 'bed_target_temper' -Default -1)
            $upgradeStatus = [string](Get-ObjectProperty -Object $upgradeState -Name 'status')
            $sdcard = [bool](Get-ObjectProperty -Object $print -Name 'sdcard' -Default $false)

            $checks = @(
                [pscustomobject]@{ Check = 'Printer idle';        Required = $true;  Pass = ($printType -eq 'idle'); Detail = "print_type=$printType" }
                [pscustomobject]@{ Check = 'No active error';     Required = $true;  Pass = ($printError -eq 0); Detail = "print_error=$printError" }
                [pscustomobject]@{ Check = 'Nozzle target off';   Required = $true;  Pass = ($nozzleTarget -eq 0); Detail = "target=$nozzleTarget C" }
                [pscustomobject]@{ Check = 'Bed target off';      Required = $true;  Pass = ($bedTarget -eq 0); Detail = "target=$bedTarget C" }
                [pscustomobject]@{ Check = 'Upgrade engine idle'; Required = $true;  Pass = ($upgradeStatus -eq 'IDLE'); Detail = "status=$upgradeStatus" }
                [pscustomobject]@{ Check = 'SD card available';   Required = $false; Pass = $sdcard; Detail = "sdcard=$sdcard (required only for SD-card installation)" }
            )

            $checks | Format-Table Check, Required, Pass, Detail -AutoSize

            $version = Get-A1VersionReport
            Write-Host "Current OTA version: $($version.Version)"

            try {
                $history = Get-A1FirmwareHistoryReport
                Write-Host "Firmware history entries: $($history.FirmwareOptional.Count)"
            }
            catch {
                Write-Warning "Firmware history request was rejected or unavailable: $($_.Exception.Message)"
                Write-Warning 'History retrieval is diagnostic only and is not a deployment safety prerequisite.'
            }

            $failed = @($checks | Where-Object { $_.Required -and -not $_.Pass })
            if ($failed.Count -gt 0) {
                throw "Firmware deployment preflight failed $($failed.Count) safety check(s)."
            }

            Write-Host 'Preflight passed.'
            Write-Warning 'Discovery only: the A1 Mini OTA path expects a signed Bambu firmware manifest (*.json.sig), not a raw HotFetched firmware binary.'
            return
        }


        if ($Command -eq 'firmware-offer-probe') {
            if (-not $ConfirmFirmwareOfferProbe) {
                throw 'This probe publishes the undocumented upgrade.upgrade_history message. It is restricted to the exact currently installed firmware and force_update=false. Rerun with -ConfirmFirmwareOfferProbe.'
            }
            if ([string]::IsNullOrWhiteSpace($PackagePath)) {
                throw 'Usage: .\A1Mini-Control-v6.4.2.ps1 firmware-offer-probe -PackagePath OFFICIAL_OFFLINE_ZIP -ConfirmFirmwareOfferProbe'
            }
            if (-not (Test-Path -LiteralPath $PackagePath -PathType Leaf)) {
                throw "Offline package not found: $PackagePath"
            }

            Write-Host 'Running guarded same-version firmware-offer probe...'
            Write-Warning 'This does not send upgrade.start, upgrade_confirm, or consistency_confirm.'
            Write-Warning 'The upgrade_history command is community-observed and may affect firmware-offer state. v6.4.2 blocks any version mismatch.'

            $state = Get-A1State
            $print = Get-ObjectProperty -Object $state -Name 'print' -Default $null
            $upgradeState = Get-ObjectProperty -Object $print -Name 'upgrade_state' -Default $null

            $printType = [string](Get-ObjectProperty -Object $print -Name 'print_type')
            $printError = [int64](Get-ObjectProperty -Object $print -Name 'print_error' -Default -1)
            $nozzleTarget = [double](Get-ObjectProperty -Object $print -Name 'nozzle_target_temper' -Default -1)
            $bedTarget = [double](Get-ObjectProperty -Object $print -Name 'bed_target_temper' -Default -1)
            $upgradeStatus = [string](Get-ObjectProperty -Object $upgradeState -Name 'status')

            $probeChecks = @(
                [pscustomobject]@{ Check = 'Printer idle';        Pass = ($printType -eq 'idle'); Detail = "print_type=$printType" }
                [pscustomobject]@{ Check = 'No active error';     Pass = ($printError -eq 0); Detail = "print_error=$printError" }
                [pscustomobject]@{ Check = 'Nozzle target off';   Pass = ($nozzleTarget -eq 0); Detail = "target=$nozzleTarget C" }
                [pscustomobject]@{ Check = 'Bed target off';      Pass = ($bedTarget -eq 0); Detail = "target=$bedTarget C" }
                [pscustomobject]@{ Check = 'Upgrade engine idle'; Pass = ($upgradeStatus -eq 'IDLE'); Detail = "status=$upgradeStatus" }
            )
            $probeChecks | Format-Table Check, Pass, Detail -AutoSize
            $failedProbeChecks = @($probeChecks | Where-Object { -not $_.Pass })
            if ($failedProbeChecks.Count -gt 0) {
                throw "Firmware-offer probe blocked by $($failedProbeChecks.Count) failed safety check(s)."
            }

            $versionReport = Get-A1VersionReport
            $currentVersion = [string]$versionReport.Version

            $inspectRun = Invoke-A1Python -Arguments @(
                $BridgePath,
                'inspect-package',
                '--package-path',
                (Resolve-Path -LiteralPath $PackagePath).Path
            )
            if ($inspectRun.ExitCode -ne 0) {
                throw "Offline package inspection failed.`n$($inspectRun.Text)"
            }
            $inspection = $inspectRun.Text | ConvertFrom-Json

            $packageValid = (
                [bool]$inspection.zip_integrity -and
                [bool]$inspection.package_list_inner_hash_valid -and
                [bool]$inspection.n1_manifest_inner_hash_valid -and
                [bool]$inspection.package_hashes_valid -and
                [bool]$inspection.component_md5_valid -and
                ([string]$inspection.model_name -eq 'N1')
            )
            if (-not $packageValid) {
                throw 'Offline package failed one or more signature-wrapper/hash-chain validation checks.'
            }
            if ([string]$inspection.version -ne $currentVersion) {
                throw "v6.4.2 blocks version mismatch: printer=$currentVersion package=$($inspection.version). Use the exact currently installed official package for this probe."
            }

            $probeRoot = Join-Path $DataDir 'firmware-offer-probes'
            New-Item -ItemType Directory -Path $probeRoot -Force | Out-Null
            $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
            $probeDirectory = Join-Path $probeRoot $stamp

            $offerSequence = Get-NextA1SequenceId
            $historySequence = Get-NextA1SequenceId

            $probeRun = Invoke-A1Python -Arguments @(
                $BridgePath,
                'offer-probe',
                '--package-path',
                (Resolve-Path -LiteralPath $PackagePath).Path,
                '--printer-ip',
                $credentials.Ip,
                '--expected-version',
                $currentVersion,
                '--offer-sequence',
                $offerSequence,
                '--history-sequence',
                $historySequence,
                '--output-dir',
                $probeDirectory,
                '--timeout',
                $Timeout.ToString([System.Globalization.CultureInfo]::InvariantCulture)
            )

            if ([string]::IsNullOrWhiteSpace($probeRun.Text)) {
                throw "Firmware-offer probe returned no summary. Exit code: $($probeRun.ExitCode)"
            }

            try {
                $probe = $probeRun.Text | ConvertFrom-Json
            }
            catch {
                throw "Could not parse firmware-offer probe summary.`n$($probeRun.Text)"
            }

            $lastProbePath = Join-Path $DataDir 'last-firmware-offer-probe.json'
            [System.IO.File]::WriteAllText(
                $lastProbePath,
                ($probe | ConvertTo-Json -Depth 30),
                [System.Text.UTF8Encoding]::new($false)
            )

            Write-Host "Package version:          $($inspection.version)"
            Write-Host "Manifest URL:             $($probe.manifest_url)"
            Write-Host "Offer response received:  $($probe.offer_response_received)"
            Write-Host "Offer accepted:           $($probe.offer_accepted)"
            Write-Host "Offer error:              $($probe.offer_err_code) ($($probe.offer_err_code_hex))"
            Write-Host "History response:         $($probe.history_response_received)"
            Write-Host "History accepted:         $($probe.history_accepted)"
            Write-Host "History error:            $($probe.history_err_code) ($($probe.history_err_code_hex))"
            Write-Host "Offer visible in history: $($probe.offer_visible_in_history)"
            Write-Host "HTTP manifest requests:   $($probe.http_request_count)"
            Write-Host "Upgrade action observed:  $($probe.action_started)"
            Write-Host "Evidence directory:       $probeDirectory"

            if ($probe.action_started) {
                Write-Warning 'The printer reported a non-idle upgrade state during the same-version probe. Do not send another probe until this state is understood.'
            }
            if ($probeRun.ExitCode -eq 5) {
                throw "Printer rejected one or both firmware discovery commands. Evidence was preserved at $probeDirectory"
            }
            if ($probeRun.ExitCode -ne 0) {
                throw "Firmware-offer probe completed with exit code $($probeRun.ExitCode). Evidence was preserved at $probeDirectory"
            }
            return
        }

        if ($Command -eq 'firmware-offer-clear') {
            $lastProbePath = Join-Path $DataDir 'last-firmware-offer-probe.json'
            if (Test-Path -LiteralPath $lastProbePath -PathType Leaf) {
                Remove-Item -LiteralPath $lastProbePath -Force
                Write-Host "Removed local probe pointer: $lastProbePath"
            }
            else {
                Write-Host 'No local probe pointer was present.'
            }

            $history = Get-A1FirmwareHistoryReport
            if ($history.FirmwareOptional.Count -eq 0) {
                Write-Host 'Printer currently returns no firmware_optional entries.'
            }
            else {
                Write-Warning 'Printer still returns firmware_optional entries. v6.4.2 will not send an unverified remote clear payload.'
                $history.FirmwareOptional | ConvertTo-Json -Depth 20
            }
            return
        }

        if ($Command -eq 'firmware-monitor') {
            [void](Invoke-A1FirmwareMonitor -MonitorDuration $Duration)
            return
        }

        if ($Command -eq 'firmware-verify') {
            $inspection = $null
            $expectedVersion = if (-not [string]::IsNullOrWhiteSpace($Arg1)) { $Arg1 } else { $null }

            if (-not [string]::IsNullOrWhiteSpace($PackagePath)) {
                $inspection = Get-A1OfflinePackageInspection -Path $PackagePath
                Assert-A1StageablePackage -Inspection $inspection
                $expectedVersion = [string]$inspection.version
            }

            [void](Invoke-A1FirmwareVerification `
                -Inspection $inspection `
                -ExpectedVersion $expectedVersion `
                -Credentials $credentials)
            return
        }

        if ($Command -eq 'firmware-workflow') {
            if (-not $ConfirmSdStage) {
                throw 'The guided workflow stages the firmware ZIP to the selected SD card. Rerun with -ConfirmSdStage.'
            }
            if ([string]::IsNullOrWhiteSpace($PackagePath) -or [string]::IsNullOrWhiteSpace($SdDrive)) {
                throw 'Usage: .\A1Mini-Control-v6.4.2.ps1 firmware-workflow -PackagePath OFFICIAL_OFFLINE_ZIP -SdDrive E: -ConfirmSdStage'
            }

            Write-Host '=== HotFetched A1 Mini Offline Firmware Workflow ==='
            Write-Host ''

            $inspection = Get-A1OfflinePackageInspection -Path $PackagePath
            Assert-A1StageablePackage -Inspection $inspection
            $driveInfo = Resolve-A1SdDriveInfo -RequestedDrive $SdDrive -PermitFixedDrive:$AllowFixedDrive

            Write-Host 'Step 1 of 4: Printer safety preflight'
            $state = Get-A1State
            $print = Get-ObjectProperty -Object $state -Name 'print' -Default $null
            $upgradeState = Get-ObjectProperty -Object $print -Name 'upgrade_state' -Default $null

            $checks = @(
                [pscustomobject]@{ Check = 'Printer idle'; Pass = ([string](Get-ObjectProperty -Object $print -Name 'print_type') -eq 'idle') }
                [pscustomobject]@{ Check = 'No active error'; Pass = ([int64](Get-ObjectProperty -Object $print -Name 'print_error' -Default -1) -eq 0) }
                [pscustomobject]@{ Check = 'Nozzle target off'; Pass = ([double](Get-ObjectProperty -Object $print -Name 'nozzle_target_temper' -Default -1) -eq 0) }
                [pscustomobject]@{ Check = 'Bed target off'; Pass = ([double](Get-ObjectProperty -Object $print -Name 'bed_target_temper' -Default -1) -eq 0) }
                [pscustomobject]@{ Check = 'Upgrade engine idle'; Pass = ([string](Get-ObjectProperty -Object $upgradeState -Name 'status') -eq 'IDLE') }
            )
            $checks | Format-Table Check, Pass -AutoSize
            $failedChecks = @($checks | Where-Object { -not $_.Pass })
            if ($failedChecks.Count -gt 0) {
                throw "Workflow blocked by $($failedChecks.Count) failed printer safety check(s)."
            }

            $currentVersion = Get-A1VersionReport
            Write-Host "Current printer OTA: $($currentVersion.Version)"
            Write-Host "Selected package OTA: $($inspection.version)"
            Write-Host ''

            Write-Host 'Step 2 of 4: Validate and stage the package'
            Show-A1OfflinePackageInspection -Inspection $inspection
            [void](Invoke-A1PackageStage -Inspection $inspection -DriveInfo $driveInfo)
            Write-Host ''

            Write-Host 'Step 3 of 4: Move the SD card to the printer'
            Write-Host '1. Use Windows Safely Remove Hardware.'
            Write-Host '2. Insert the SD card into the A1 Mini.'
            Write-Host '3. Open the printer firmware screen and select the offline package.'
            Write-Host '4. Do not press the final Update/Confirm button yet.'
            Write-Host ''
            $response = Read-Host 'Return here and press ENTER when the printer is ready; type Q to stop'
            if ([string]$response -match '^[Qq]$') {
                Write-Host 'Workflow stopped after staging. The SD package remains ready.'
                return
            }

            Write-Host ''
            Write-Host 'Monitoring is active. Confirm the update on the printer now.'
            $monitor = Invoke-A1FirmwareMonitor -MonitorDuration $Duration

            if (-not [bool]$monitor.upgrade_started) {
                throw 'No new firmware update was observed before the monitor ended.'
            }
            if ([string]$monitor.terminal_result -ne 'success') {
                throw "Firmware monitor ended with result '$($monitor.terminal_result)'. Review $($monitor.output_dir)"
            }

            Write-Host ''
            Write-Host 'Step 4 of 4: Verify installed modules'
            Start-Sleep -Seconds 3
            [void](Invoke-A1FirmwareVerification `
                -Inspection $inspection `
                -ExpectedVersion ([string]$inspection.version) `
                -Credentials $credentials)

            Write-Host ''
            Write-Host 'VERIFIED — All installed A1 Mini modules match the staged package.'
            return
        }

        if ($Command -eq 'watch') {
            Write-Host "Watching printer every $Interval second(s). Press Ctrl+C to stop."

            try {
                while ($true) {
                    $started = [DateTime]::UtcNow

                    try {
                        $state = Get-A1State
                        Write-Host (Format-A1StateLine -State $state)
                    }
                    catch [System.Management.Automation.PipelineStoppedException] {
                        break
                    }
                    catch {
                        Write-Warning "Status poll failed: $($_.Exception.Message)"
                    }

                    $elapsedMs = ([DateTime]::UtcNow - $started).TotalMilliseconds
                    $sleepMs = [int][math]::Max(0, ($Interval * 1000) - $elapsedMs)
                    if ($sleepMs -gt 0) {
                        Start-Sleep -Milliseconds $sleepMs
                    }
                }
            }
            catch [System.Management.Automation.PipelineStoppedException] {
                # Ctrl+C while the child Python process is active.
            }
            finally {
                Write-Host 'Watch stopped.'
            }
            return
        }

        switch ($Command) {
            'led' {
                if ([string]::IsNullOrWhiteSpace($Arg1)) {
                    throw 'Usage: .\A1Mini-Control-v6.4.2.ps1 led on|off|flashing'
                }

                $stateName = $Arg1.ToLowerInvariant()
                if ($stateName -notin @('on', 'off', 'flashing')) {
                    throw "Invalid LED state '$Arg1'. Use on, off, or flashing."
                }

                $payload = New-A1SystemPayload -CommandName 'ledctrl' -Extra ([ordered]@{
                    led_node     = 'chamber_light'
                    led_mode     = $stateName
                    led_on_time  = 500
                    led_off_time = 500
                    loop_times   = 1
                    interval_time = 1000
                })

                [void](Invoke-A1Payload -Payload $payload)

                [void](Wait-A1Condition -Description "chamber light $stateName" -Condition {
                    param($state)
                    $print = Get-ObjectProperty -Object $state -Name 'print' -Default $null
                    (Get-A1LightMode -PrintState $print) -eq $stateName
                })
            }

            'home' {
                if (-not $ConfirmMotion) {
                    throw 'Homing moves the printer. Clear the bed/toolhead area, then rerun with -ConfirmMotion.'
                }

                $payload = New-A1PrintPayload -CommandName 'gcode_line' -Extra ([ordered]@{
                    param = "G28`n"
                })
                [void](Invoke-A1Payload -Payload $payload)
            }

            'jog' {
                if (-not $ConfirmMotion) {
                    throw 'Jogging moves the printer. Clear the motion path, then rerun with -ConfirmMotion.'
                }
                if ([string]::IsNullOrWhiteSpace($Arg1) -or [string]::IsNullOrWhiteSpace($Arg2)) {
                    throw 'Usage: .\A1Mini-Control-v6.4.2.ps1 jog X|Y|Z DISTANCE_MM [-Feed N] -ConfirmMotion'
                }

                $axis = $Arg1.ToUpperInvariant()
                if ($axis -notin @('X', 'Y', 'Z')) {
                    throw "Invalid axis '$Arg1'. Only X, Y, and Z are enabled."
                }

                $distance = 0.0
                $parsed = [double]::TryParse(
                    $Arg2,
                    [System.Globalization.NumberStyles]::Float,
                    [System.Globalization.CultureInfo]::InvariantCulture,
                    [ref]$distance
                )
                if (-not $parsed -or $distance -eq 0) {
                    throw "Invalid jog distance '$Arg2'."
                }

                $limit = if ($axis -eq 'Z') { 2.0 } else { 10.0 }
                if ([math]::Abs($distance) -gt $limit) {
                    throw "Jog blocked: $axis is limited to +/-$limit mm per command."
                }

                $effectiveFeed = if ($PSBoundParameters.ContainsKey('Feed')) {
                    $Feed
                }
                elseif ($axis -eq 'Z') {
                    900
                }
                else {
                    3000
                }

                if ($effectiveFeed -le 0 -or $effectiveFeed -gt 6000) {
                    throw 'Feed must be between 1 and 6000 mm/min.'
                }

                $distanceText = $distance.ToString(
                    '0.###',
                    [System.Globalization.CultureInfo]::InvariantCulture
                )

                $gcode = "G91`nG1 $axis$distanceText F$effectiveFeed`nG90`n"
                $payload = New-A1PrintPayload -CommandName 'gcode_line' -Extra ([ordered]@{
                    param = $gcode
                })
                [void](Invoke-A1Payload -Payload $payload)
            }

            'pause' {
                if (-not $ConfirmPrintControl) {
                    throw 'Pausing changes the active print. Rerun with -ConfirmPrintControl.'
                }

                $payload = New-A1PrintPayload -CommandName 'pause' -Extra ([ordered]@{
                    param = ''
                })
                [void](Invoke-A1Payload -Payload $payload)
            }

            'resume' {
                if (-not $ConfirmPrintControl) {
                    throw 'Resuming changes the active print. Rerun with -ConfirmPrintControl.'
                }

                $payload = New-A1PrintPayload -CommandName 'resume' -Extra ([ordered]@{
                    param = ''
                })
                [void](Invoke-A1Payload -Payload $payload)
            }

            'stop' {
                if (-not $ConfirmPrintControl) {
                    throw 'Stopping aborts the active print. Rerun with -ConfirmPrintControl.'
                }

                $payload = New-A1PrintPayload -CommandName 'stop' -Extra ([ordered]@{
                    param = ''
                })
                [void](Invoke-A1Payload -Payload $payload)
            }

            'set-temp' {
                if (-not $ConfirmHeat) {
                    throw 'Temperature control activates heaters. Rerun with -ConfirmHeat.'
                }
                if ([string]::IsNullOrWhiteSpace($Arg1) -or [string]::IsNullOrWhiteSpace($Arg2)) {
                    throw 'Usage: .\A1Mini-Control-v6.4.2.ps1 set-temp bed|nozzle DEGREES [-Index N] -ConfirmHeat'
                }

                $target = $Arg1.ToLowerInvariant()
                if ($target -notin @('bed', 'nozzle')) {
                    throw "Invalid heater '$Arg1'. Use bed or nozzle."
                }

                $temperature = 0.0
                $parsed = [double]::TryParse(
                    $Arg2,
                    [System.Globalization.NumberStyles]::Float,
                    [System.Globalization.CultureInfo]::InvariantCulture,
                    [ref]$temperature
                )
                if (-not $parsed) {
                    throw "Invalid temperature '$Arg2'."
                }

                $maximum = if ($target -eq 'bed') { 120.0 } else { 300.0 }
                if ($temperature -lt 0 -or $temperature -gt $maximum) {
                    throw "Temperature blocked: $target must be between 0 and $maximum C."
                }

                $temperatureText = $temperature.ToString(
                    '0.###',
                    [System.Globalization.CultureInfo]::InvariantCulture
                )

                if ($target -eq 'bed') {
                    $gcode = "M140 S$temperatureText"
                    $stateProperty = 'bed_target_temper'
                }
                else {
                    $gcode = "M104 T$Index S$temperatureText"
                    $stateProperty = 'nozzle_target_temper'
                }

                $payload = New-A1PrintPayload -CommandName 'gcode_line' -Extra ([ordered]@{
                    param = "$gcode`n"
                })
                [void](Invoke-A1Payload -Payload $payload)

                [void](Wait-A1Condition -Description "$target target $temperature C" -Condition {
                    param($state)
                    $print = Get-ObjectProperty -Object $state -Name 'print' -Default $null
                    $reported = [double](Get-ObjectProperty -Object $print -Name $stateProperty -Default -999)
                    [math]::Abs($reported - $temperature) -le 0.5
                })
            }

            'fan' {
                if ([string]::IsNullOrWhiteSpace($Arg1) -or [string]::IsNullOrWhiteSpace($Arg2)) {
                    throw 'Usage: .\A1Mini-Control-v6.4.2.ps1 fan part PERCENT'
                }
                if ($Arg1.ToLowerInvariant() -ne 'part') {
                    throw "Invalid fan '$Arg1'. Only the part-cooling fan is enabled."
                }

                $percent = 0.0
                $parsed = [double]::TryParse(
                    $Arg2,
                    [System.Globalization.NumberStyles]::Float,
                    [System.Globalization.CultureInfo]::InvariantCulture,
                    [ref]$percent
                )
                if (-not $parsed -or $percent -lt 0 -or $percent -gt 100) {
                    throw "Invalid fan percentage '$Arg2'. Use 0 through 100."
                }

                $pwm = [int][math]::Round(($percent / 100.0) * 255.0)
                $expectedRaw = [int][math]::Round(($percent / 100.0) * 15.0)
                $gcode = "M106 P1 S$pwm"

                $payload = New-A1PrintPayload -CommandName 'gcode_line' -Extra ([ordered]@{
                    param = "$gcode`n"
                })
                [void](Invoke-A1Payload -Payload $payload)

                [void](Wait-A1Condition -Description "part fan approximately $percent%" -Condition {
                    param($state)
                    $print = Get-ObjectProperty -Object $state -Name 'print' -Default $null
                    $reported = [int](Get-ObjectProperty -Object $print -Name 'cooling_fan_speed' -Default -99)

                    if ($expectedRaw -eq 0) {
                        return $reported -eq 0
                    }

                    return [math]::Abs($reported - $expectedRaw) -le 1
                })
            }

            'all-off' {
                if (-not $ConfirmAllOff) {
                    throw 'all-off disables nozzle heat, bed heat, part fan, and chamber light. Rerun with -ConfirmAllOff.'
                }

                Write-Warning 'Emergency shutdown command: nozzle target 0, bed target 0, part fan 0, chamber light off.'

                $gcodePayload = New-A1PrintPayload -CommandName 'gcode_line' -Extra ([ordered]@{
                    param = "M104 T0 S0`nM140 S0`nM106 P1 S0`n"
                })
                [void](Invoke-A1Payload -Payload $gcodePayload)

                $lightPayload = New-A1SystemPayload -CommandName 'ledctrl' -Extra ([ordered]@{
                    led_node      = 'chamber_light'
                    led_mode      = 'off'
                    led_on_time   = 500
                    led_off_time  = 500
                    loop_times    = 1
                    interval_time = 1000
                })
                [void](Invoke-A1Payload -Payload $lightPayload)

                $verifiedState = Wait-A1Condition -Description 'heater targets 0, part fan stopped, and light off' -Condition {
                    param($state)
                    $print = Get-ObjectProperty -Object $state -Name 'print' -Default $null

                    $nozzleTarget = [double](Get-ObjectProperty -Object $print -Name 'nozzle_target_temper' -Default -1)
                    $bedTarget = [double](Get-ObjectProperty -Object $print -Name 'bed_target_temper' -Default -1)
                    $fanRaw = [int](Get-ObjectProperty -Object $print -Name 'cooling_fan_speed' -Default -1)
                    $lightMode = Get-A1LightMode -PrintState $print

                    return (
                        $nozzleTarget -eq 0 -and
                        $bedTarget -eq 0 -and
                        $fanRaw -eq 0 -and
                        $lightMode -eq 'off'
                    )
                }

                Write-Host (Format-A1StateLine -State $verifiedState)
            }
        }
    }
}

try {
    Invoke-A1Main
}
catch [System.Management.Automation.PipelineStoppedException] {
    Write-Host 'Canceled.'
}
