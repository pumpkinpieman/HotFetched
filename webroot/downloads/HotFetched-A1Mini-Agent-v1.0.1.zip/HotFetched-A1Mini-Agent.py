#!/usr/bin/env python3
"""HotFetched A1 Mini local Windows agent.

The agent binds only to 127.0.0.1 and exposes a paired local HTTP API used by
HotFetched's browser UI. It never exposes the LAN access code and never sends
upgrade.start, upgrade_confirm, or consistency_confirm.
"""

from __future__ import annotations

import cgi
import hashlib
import importlib.util
import json
import os
import re
import secrets
import shutil
import subprocess
import sys
import threading
import time
import traceback
import uuid
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


AGENT_VERSION = "1.0.1"
HOST = "127.0.0.1"
DEFAULT_PORT = 47841
MAX_UPLOAD_BYTES = 512 * 1024 * 1024
TOKEN_TTL_SECONDS = 12 * 60 * 60
PAIR_CODE_TTL_SECONDS = 15 * 60


def now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def compact_json(value: Any) -> str:
    return json.dumps(value, separators=(",", ":"), ensure_ascii=True)


class AgentError(RuntimeError):
    pass


class Job:
    def __init__(self, kind: str):
        self.id = uuid.uuid4().hex
        self.kind = kind
        self.status = "queued"
        self.progress = 0
        self.lines: list[str] = []
        self.result: dict[str, Any] | None = None
        self.error: str | None = None
        self.created_at = now_iso()
        self.updated_at = self.created_at
        self.lock = threading.Lock()

    def line(self, value: str) -> None:
        value = value.rstrip("\r\n")
        with self.lock:
            self.lines.append(value)
            if len(self.lines) > 1000:
                self.lines = self.lines[-1000:]
            self.updated_at = now_iso()

    def set_progress(self, value: int) -> None:
        with self.lock:
            self.progress = max(0, min(100, int(value)))
            self.updated_at = now_iso()

    def snapshot(self) -> dict[str, Any]:
        with self.lock:
            return {
                "id": self.id,
                "kind": self.kind,
                "status": self.status,
                "progress": self.progress,
                "lines": list(self.lines),
                "result": self.result,
                "error": self.error,
                "created_at": self.created_at,
                "updated_at": self.updated_at,
            }


class AgentState:
    def __init__(self) -> None:
        self.install_dir = Path(__file__).resolve().parent
        self.data_dir = Path(
            os.environ.get(
                "LOCALAPPDATA",
                str(Path.home() / "AppData" / "Local"),
            )
        ) / "HotFetched" / "A1Mini-Agent"
        self.data_dir.mkdir(parents=True, exist_ok=True)

        self.package_dir = self.data_dir / "packages"
        self.package_dir.mkdir(parents=True, exist_ok=True)
        self.evidence_dir = self.data_dir / "evidence"
        self.evidence_dir.mkdir(parents=True, exist_ok=True)

        self.registry_path = self.data_dir / "packages.json"
        self.pid_path = self.data_dir / "agent.pid"
        self.log_path = self.data_dir / "agent.log"

        self.controller_path = self.install_dir / "A1Mini-Control-v6.4.2.ps1"
        self.bridge_path = self.install_dir / "A1Mini-Bridge-v6.4.2.py"

        # The background launcher intentionally starts this agent with
        # pythonw.exe so no console window remains open. PowerShell must not
        # use pythonw.exe for controller subprocesses because Windows
        # PowerShell 5.1 may not populate $LASTEXITCODE for GUI-subsystem
        # executables. Normalize the child runtime back to python.exe.
        runtime_executable = Path(sys.executable)
        if runtime_executable.name.lower() == "pythonw.exe":
            console_executable = runtime_executable.with_name("python.exe")
            if console_executable.is_file():
                runtime_executable = console_executable
        self.python_exe = runtime_executable

        self.bridge = self._load_bridge()
        self.packages = self._load_registry()
        self.packages_lock = threading.Lock()

        self.jobs: dict[str, Job] = {}
        self.jobs_lock = threading.Lock()

        self.tokens: dict[str, float] = {}
        self.tokens_lock = threading.Lock()
        self.pair_code = self._new_pair_code()
        self.pair_code_expires = time.time() + PAIR_CODE_TTL_SECONDS

    def _load_bridge(self):
        if not self.bridge_path.is_file():
            raise AgentError(f"Bridge not found: {self.bridge_path}")
        spec = importlib.util.spec_from_file_location(
            "hotfetched_a1mini_bridge",
            self.bridge_path,
        )
        if spec is None or spec.loader is None:
            raise AgentError("Could not load A1 Mini bridge")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def _new_pair_code(self) -> str:
        return f"{secrets.randbelow(900000) + 100000:06d}"

    def current_pair_code(self) -> str:
        if time.time() >= self.pair_code_expires:
            self.pair_code = self._new_pair_code()
            self.pair_code_expires = time.time() + PAIR_CODE_TTL_SECONDS
        return self.pair_code

    def pair(self, supplied: str) -> str:
        expected = self.current_pair_code()
        if not secrets.compare_digest(str(supplied).strip(), expected):
            raise AgentError("Pairing code is incorrect or expired")
        token = secrets.token_urlsafe(32)
        with self.tokens_lock:
            self.tokens[token] = time.time() + TOKEN_TTL_SECONDS
        self.pair_code = self._new_pair_code()
        self.pair_code_expires = time.time() + PAIR_CODE_TTL_SECONDS
        return token

    def token_valid(self, token: str | None) -> bool:
        if not token:
            return False
        with self.tokens_lock:
            expires = self.tokens.get(token)
            if expires is None:
                return False
            if time.time() >= expires:
                self.tokens.pop(token, None)
                return False
            return True

    def _load_registry(self) -> dict[str, dict[str, Any]]:
        if not self.registry_path.is_file():
            return {}
        try:
            raw = json.loads(self.registry_path.read_text(encoding="utf-8"))
            if not isinstance(raw, dict):
                return {}
            valid: dict[str, dict[str, Any]] = {}
            for package_id, entry in raw.items():
                if not isinstance(entry, dict):
                    continue
                path = Path(str(entry.get("path", "")))
                if path.is_file():
                    valid[str(package_id)] = entry
            return valid
        except Exception:
            return {}

    def save_registry(self) -> None:
        temporary = self.registry_path.with_suffix(".tmp")
        temporary.write_text(
            json.dumps(self.packages, indent=2) + "\n",
            encoding="utf-8",
        )
        os.replace(temporary, self.registry_path)

    def add_job(self, kind: str) -> Job:
        job = Job(kind)
        with self.jobs_lock:
            self.jobs[job.id] = job
        return job

    def get_job(self, job_id: str) -> Job | None:
        with self.jobs_lock:
            return self.jobs.get(job_id)

    def log(self, message: str) -> None:
        safe = message.replace("\r", " ").replace("\n", " ")
        with self.log_path.open("a", encoding="utf-8") as handle:
            handle.write(f"{now_iso()} {safe}\n")


STATE = AgentState()


def sanitize_filename(value: str) -> str:
    value = Path(value).name
    value = re.sub(r"[^A-Za-z0-9._-]", "_", value)
    return value[:180] or "firmware.zip"


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def serializable_inspection(inspection: dict[str, Any]) -> dict[str, Any]:
    return {
        key: value
        for key, value in inspection.items()
        if key != "manifest_bytes"
    }


def inspect_package(path: Path) -> dict[str, Any]:
    inspection = STATE.bridge.inspect_offline_package(path)
    STATE.bridge.assert_stageable_n1_package(inspection)
    return serializable_inspection(inspection)


def powershell_executable() -> str:
    system_root = os.environ.get("SystemRoot", r"C:\Windows")
    candidate = Path(system_root) / "System32" / "WindowsPowerShell" / "v1.0" / "powershell.exe"
    return str(candidate if candidate.is_file() else "powershell.exe")


def run_controller(
    command: str,
    extra_args: list[str] | None = None,
    *,
    access_code: str | None = None,
    timeout: int = 90,
) -> dict[str, Any]:
    args = [
        powershell_executable(),
        "-NoLogo",
        "-NoProfile",
        "-NonInteractive",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        str(STATE.controller_path),
        command,
        "-PythonExe",
        str(STATE.python_exe),
    ]
    if extra_args:
        args.extend(extra_args)

    environment = os.environ.copy()
    environment["PYTHONIOENCODING"] = "utf-8"
    if access_code is not None:
        environment["X2D_CODE"] = access_code

    completed = subprocess.run(
        args,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        env=environment,
        timeout=timeout,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    return {
        "ok": completed.returncode == 0,
        "exit_code": completed.returncode,
        "stdout": completed.stdout.strip(),
        "stderr": completed.stderr.strip(),
    }


def logical_drives() -> list[dict[str, Any]]:
    script = r"""
$items = Get-CimInstance Win32_LogicalDisk |
    Select-Object DeviceID,VolumeName,FileSystem,DriveType,Size,FreeSpace
@($items) | ConvertTo-Json -Depth 3 -Compress
"""
    completed = subprocess.run(
        [
            powershell_executable(),
            "-NoLogo",
            "-NoProfile",
            "-NonInteractive",
            "-Command",
            script,
        ],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=20,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    if completed.returncode != 0:
        raise AgentError(completed.stderr.strip() or "Could not enumerate drives")

    raw = completed.stdout.strip()
    if not raw:
        return []
    value = json.loads(raw)
    rows = value if isinstance(value, list) else [value]
    result = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        device_id = str(row.get("DeviceID", "")).upper()
        if not re.fullmatch(r"[A-Z]:", device_id):
            continue
        result.append(
            {
                "device_id": device_id,
                "root": device_id + "\\",
                "volume_name": row.get("VolumeName") or "",
                "filesystem": row.get("FileSystem") or "",
                "drive_type": int(row.get("DriveType") or 0),
                "size": int(row.get("Size") or 0),
                "free_space": int(row.get("FreeSpace") or 0),
                "removable": int(row.get("DriveType") or 0) == 2,
            }
        )
    return result


def require_package(package_id: str) -> dict[str, Any]:
    with STATE.packages_lock:
        entry = STATE.packages.get(package_id)
    if not entry:
        raise AgentError("Unknown package")
    path = Path(str(entry["path"]))
    if not path.is_file():
        raise AgentError("Stored package file is missing")
    return entry


def stage_job(job: Job, package_id: str, drive_id: str, allow_fixed: bool) -> None:
    job.status = "running"
    job.line("Validating destination drive.")
    try:
        package = require_package(package_id)
        package_path = Path(str(package["path"]))
        inspection = package["inspection"]

        drive_id = drive_id.strip().upper().rstrip("\\")
        if not re.fullmatch(r"[A-Z]:", drive_id):
            raise AgentError("Invalid drive letter")

        drive = next(
            (row for row in logical_drives() if row["device_id"] == drive_id),
            None,
        )
        if drive is None:
            raise AgentError(f"Drive {drive_id} is not mounted")
        if not drive["filesystem"]:
            raise AgentError(f"Drive {drive_id} is not ready")
        if drive["drive_type"] != 2 and not (
            drive["drive_type"] == 3 and allow_fixed
        ):
            raise AgentError(
                f"Drive {drive_id} is not reported as removable media"
            )

        source_size = int(inspection["package_size"])
        if drive["free_space"] < source_size + (4 * 1024 * 1024):
            raise AgentError("The selected drive does not have enough free space")

        destination_root = Path(drive["root"])
        target = destination_root / str(inspection["package_filename"])
        partial = destination_root / (
            "." + str(inspection["package_filename"]) + ".hotfetched.partial"
        )
        expected_hash = str(inspection["package_sha256"])

        if target.exists():
            job.line("A package with the same name is already present; verifying it.")
            existing_hash = sha256_file(target)
            if existing_hash != expected_hash:
                raise AgentError(
                    "A different file with the same package name already exists"
                )
            status = "already_present"
            job.set_progress(100)
        else:
            partial.unlink(missing_ok=True)
            copied = 0
            digest = hashlib.sha256()
            with package_path.open("rb") as source, partial.open("xb") as output:
                while True:
                    chunk = source.read(1024 * 1024)
                    if not chunk:
                        break
                    output.write(chunk)
                    digest.update(chunk)
                    copied += len(chunk)
                    percent = int((copied * 100) / source_size)
                    job.set_progress(percent)
                    if percent % 10 == 0:
                        job.line(f"Copied {percent}%")
                output.flush()
                os.fsync(output.fileno())

            if digest.hexdigest() != expected_hash:
                partial.unlink(missing_ok=True)
                raise AgentError("Copied data hash does not match the source")
            os.replace(partial, target)
            if sha256_file(target) != expected_hash:
                raise AgentError("Final SD-card hash verification failed")
            status = "copied"
            job.set_progress(100)

        evidence = STATE.evidence_dir / f"stage-{datetime.now().strftime('%Y%m%d-%H%M%S')}-{job.id[:8]}"
        evidence.mkdir(parents=True, exist_ok=False)
        result = {
            "status": status,
            "drive": drive,
            "destination_path": str(target),
            "sha256": expected_hash,
            "package": inspection,
            "evidence_dir": str(evidence),
        }
        (evidence / "staging-record.json").write_text(
            json.dumps(result, indent=2) + "\n",
            encoding="utf-8",
        )

        job.result = result
        job.status = "success"
        job.line("SD staging completed and SHA-256 matched.")
    except Exception as exc:
        job.error = str(exc)
        job.status = "failed"
        job.line(f"ERROR: {exc}")
    finally:
        job.updated_at = now_iso()


def monitor_job(job: Job, duration: int) -> None:
    job.status = "running"
    job.line("Starting passive printer firmware monitor.")
    args = [
        powershell_executable(),
        "-NoLogo",
        "-NoProfile",
        "-NonInteractive",
        "-ExecutionPolicy",
        "Bypass",
        "-File",
        str(STATE.controller_path),
        "firmware-monitor",
        "-Duration",
        str(duration),
        "-PythonExe",
        str(STATE.python_exe),
    ]
    environment = os.environ.copy()
    environment["PYTHONIOENCODING"] = "utf-8"

    try:
        process = subprocess.Popen(
            args,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            encoding="utf-8",
            errors="replace",
            env=environment,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        assert process.stdout is not None
        success_seen = False
        for line in process.stdout:
            clean = line.rstrip()
            job.line(clean)
            match = re.search(r"Overall\s+(\d+)%", clean)
            if match:
                job.set_progress(int(match.group(1)))
            if "Terminal result:" in clean and "success" in clean.lower():
                success_seen = True
                job.set_progress(100)
        return_code = process.wait()
        if return_code == 0:
            job.status = "success"
            job.result = {
                "terminal_result": "success" if success_seen else "completed",
                "exit_code": return_code,
            }
        else:
            raise AgentError(f"Monitor exited with code {return_code}")
    except Exception as exc:
        job.error = str(exc)
        job.status = "failed"
        job.line(f"ERROR: {exc}")
    finally:
        job.updated_at = now_iso()


class Handler(BaseHTTPRequestHandler):
    server_version = "HotFetchedA1Agent/1.0"

    def log_message(self, fmt: str, *args: Any) -> None:
        return

    def _origin(self) -> str:
        return self.headers.get("Origin", "")

    def _cors(self) -> None:
        origin = self._origin()
        if origin:
            self.send_header("Access-Control-Allow-Origin", origin)
            self.send_header("Vary", "Origin")
        self.send_header(
            "Access-Control-Allow-Headers",
            "Authorization, Content-Type",
        )
        self.send_header(
            "Access-Control-Allow-Methods",
            "GET, POST, DELETE, OPTIONS",
        )
        self.send_header("Access-Control-Allow-Private-Network", "true")
        self.send_header("Cache-Control", "no-store")

    def _json(
        self,
        payload: dict[str, Any],
        status: int = HTTPStatus.OK,
    ) -> None:
        body = compact_json(payload).encode("utf-8")
        self.send_response(status)
        self._cors()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _html(self, html: str, status: int = HTTPStatus.OK) -> None:
        body = html.encode("utf-8")
        self.send_response(status)
        self._cors()
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _error(
        self,
        message: str,
        status: int = HTTPStatus.BAD_REQUEST,
    ) -> None:
        self._json({"ok": False, "error": message}, status)

    def _read_json(self, max_bytes: int = 1024 * 1024) -> dict[str, Any]:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            raise AgentError("Invalid Content-Length")
        if length <= 0 or length > max_bytes:
            raise AgentError("Invalid request size")
        raw = self.rfile.read(length)
        value = json.loads(raw.decode("utf-8"))
        if not isinstance(value, dict):
            raise AgentError("JSON object required")
        return value

    def _token(self) -> str | None:
        authorization = self.headers.get("Authorization", "")
        if not authorization.startswith("Bearer "):
            return None
        return authorization[7:].strip()

    def _require_auth(self) -> bool:
        if not STATE.token_valid(self._token()):
            self._error("Pairing token missing or expired", HTTPStatus.UNAUTHORIZED)
            return False
        return True

    def do_OPTIONS(self) -> None:
        self.send_response(HTTPStatus.NO_CONTENT)
        self._cors()
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_GET(self) -> None:
        path = urlparse(self.path).path

        if path == "/":
            self._html(
                "<!doctype html><meta charset='utf-8'>"
                "<title>HotFetched A1 Agent</title>"
                "<style>body{font:16px system-ui;background:#0e1117;color:#eef;"
                "max-width:700px;margin:70px auto;padding:24px}"
                "a{color:#ff8c32}</style>"
                "<h1>HotFetched A1 Mini Agent</h1>"
                "<p>The local agent is running.</p>"
                "<p><a href='/pairing'>Show pairing code</a></p>"
            )
            return

        if path == "/pairing":
            code = STATE.current_pair_code()
            self._html(
                "<!doctype html><meta charset='utf-8'>"
                "<title>HotFetched Pairing Code</title>"
                "<style>body{font:18px system-ui;background:#0e1117;color:#eef;"
                "text-align:center;margin-top:90px}"
                ".code{font:700 56px ui-monospace,monospace;letter-spacing:.18em;"
                "color:#ff8c32;margin:32px}</style>"
                "<h1>HotFetched A1 Mini Agent</h1>"
                "<p>Enter this code in the HotFetched A1 Mini page:</p>"
                f"<div class='code'>{code}</div>"
                "<p>The code expires in 15 minutes and changes after pairing.</p>"
            )
            return

        if path == "/v1/health":
            credentials_path = (
                Path(os.environ.get("LOCALAPPDATA", ""))
                / "HotFetched"
                / "A1Mini-Control"
                / "credentials.json"
            )
            self._json(
                {
                    "ok": True,
                    "agent_version": AGENT_VERSION,
                    "paired": STATE.token_valid(self._token()),
                    "controller_exists": STATE.controller_path.is_file(),
                    "bridge_exists": STATE.bridge_path.is_file(),
                    "python_executable": str(STATE.python_exe),
                    "credentials_saved": credentials_path.is_file(),
                    "package_count": len(STATE.packages),
                }
            )
            return

        if not self._require_auth():
            return

        if path == "/v1/drives":
            try:
                self._json({"ok": True, "drives": logical_drives()})
            except Exception as exc:
                self._error(str(exc), HTTPStatus.INTERNAL_SERVER_ERROR)
            return

        if path == "/v1/packages":
            with STATE.packages_lock:
                packages = [
                    {
                        "id": package_id,
                        "original_name": entry["original_name"],
                        "uploaded_at": entry["uploaded_at"],
                        "inspection": entry["inspection"],
                    }
                    for package_id, entry in STATE.packages.items()
                ]
            self._json({"ok": True, "packages": packages})
            return

        if path.startswith("/v1/jobs/"):
            job_id = path.rsplit("/", 1)[-1]
            job = STATE.get_job(job_id)
            if job is None:
                self._error("Job not found", HTTPStatus.NOT_FOUND)
                return
            self._json({"ok": True, "job": job.snapshot()})
            return

        self._error("Endpoint not found", HTTPStatus.NOT_FOUND)

    def do_POST(self) -> None:
        path = urlparse(self.path).path

        if path == "/v1/pair":
            try:
                payload = self._read_json()
                token = STATE.pair(str(payload.get("code", "")))
                self._json(
                    {
                        "ok": True,
                        "token": token,
                        "expires_in": TOKEN_TTL_SECONDS,
                    }
                )
            except Exception as exc:
                self._error(str(exc), HTTPStatus.UNAUTHORIZED)
            return

        if not self._require_auth():
            return

        if path == "/v1/packages":
            try:
                content_length = int(self.headers.get("Content-Length", "0"))
                if content_length <= 0 or content_length > MAX_UPLOAD_BYTES:
                    raise AgentError("Package upload is empty or exceeds 512 MB")

                content_type = self.headers.get("Content-Type", "")
                if not content_type.startswith("multipart/form-data"):
                    raise AgentError("multipart/form-data required")

                form = cgi.FieldStorage(
                    fp=self.rfile,
                    headers=self.headers,
                    environ={
                        "REQUEST_METHOD": "POST",
                        "CONTENT_TYPE": content_type,
                        "CONTENT_LENGTH": str(content_length),
                    },
                    keep_blank_values=True,
                )
                if "package" not in form:
                    raise AgentError("Package field is missing")
                field = form["package"]
                if isinstance(field, list):
                    field = field[0]
                if not getattr(field, "file", None):
                    raise AgentError("Uploaded package has no content")

                original_name = sanitize_filename(
                    getattr(field, "filename", "") or "firmware.zip"
                )
                if not original_name.lower().endswith(".zip"):
                    raise AgentError("Offline firmware package must be a ZIP")

                package_id = uuid.uuid4().hex
                destination = STATE.package_dir / f"{package_id}-{original_name}"
                digest = hashlib.sha256()
                total = 0
                with destination.open("xb") as output:
                    while True:
                        chunk = field.file.read(1024 * 1024)
                        if not chunk:
                            break
                        total += len(chunk)
                        if total > MAX_UPLOAD_BYTES:
                            raise AgentError("Package exceeds 512 MB")
                        output.write(chunk)
                        digest.update(chunk)

                try:
                    inspection = inspect_package(destination)
                except Exception:
                    destination.unlink(missing_ok=True)
                    raise

                if digest.hexdigest() != inspection["package_sha256"]:
                    destination.unlink(missing_ok=True)
                    raise AgentError("Upload hash changed during inspection")

                entry = {
                    "path": str(destination),
                    "original_name": original_name,
                    "uploaded_at": now_iso(),
                    "inspection": inspection,
                }
                with STATE.packages_lock:
                    STATE.packages[package_id] = entry
                    STATE.save_registry()

                self._json(
                    {
                        "ok": True,
                        "package": {
                            "id": package_id,
                            "original_name": original_name,
                            "inspection": inspection,
                        },
                    }
                )
            except Exception as exc:
                STATE.log(f"package upload failed: {type(exc).__name__}: {exc}")
                self._error(str(exc))
            return

        if path == "/v1/printer/setup":
            try:
                payload = self._read_json()
                ip = str(payload.get("ip", "")).strip()
                serial = str(payload.get("serial", "")).strip()
                access_code = str(payload.get("access_code", "")).strip()
                if not re.fullmatch(
                    r"(?:\d{1,3}\.){3}\d{1,3}",
                    ip,
                ):
                    raise AgentError("A valid printer IPv4 address is required")
                if not re.fullmatch(r"[A-Za-z0-9_-]{6,64}", serial):
                    raise AgentError("Printer serial format is invalid")
                if not (4 <= len(access_code) <= 64):
                    raise AgentError("LAN access code is required")

                result = run_controller(
                    "setup",
                    ["-Ip", ip, "-Serial", serial],
                    access_code=access_code,
                    timeout=45,
                )
                access_code = ""
                if not result["ok"]:
                    raise AgentError(
                        result["stderr"]
                        or result["stdout"]
                        or "Printer setup failed"
                    )
                self._json({"ok": True, "output": result["stdout"]})
            except Exception as exc:
                STATE.log(f"printer setup failed: {type(exc).__name__}: {exc}")
                self._error(str(exc))
            return

        if path == "/v1/printer/doctor":
            try:
                result = run_controller("doctor", timeout=30)
                self._json(
                    {
                        "ok": result["ok"],
                        "output": "\n".join(
                            value
                            for value in (
                                result["stdout"],
                                result["stderr"],
                            )
                            if value
                        ),
                        "exit_code": result["exit_code"],
                    },
                    HTTPStatus.OK if result["ok"] else HTTPStatus.BAD_GATEWAY,
                )
            except Exception as exc:
                self._error(str(exc), HTTPStatus.BAD_GATEWAY)
            return

        if path == "/v1/stage":
            try:
                payload = self._read_json()
                package_id = str(payload.get("package_id", ""))
                drive_id = str(payload.get("drive_id", ""))
                allow_fixed = bool(payload.get("allow_fixed", False))
                require_package(package_id)
                job = STATE.add_job("stage")
                threading.Thread(
                    target=stage_job,
                    args=(job, package_id, drive_id, allow_fixed),
                    daemon=True,
                ).start()
                self._json({"ok": True, "job_id": job.id})
            except Exception as exc:
                self._error(str(exc))
            return

        if path == "/v1/monitor":
            try:
                payload = self._read_json()
                duration = int(payload.get("duration", 900))
                if duration < 30 or duration > 3600:
                    raise AgentError("Monitor duration must be 30–3600 seconds")
                job = STATE.add_job("monitor")
                threading.Thread(
                    target=monitor_job,
                    args=(job, duration),
                    daemon=True,
                ).start()
                self._json({"ok": True, "job_id": job.id})
            except Exception as exc:
                self._error(str(exc))
            return

        if path == "/v1/verify":
            try:
                payload = self._read_json()
                package_id = str(payload.get("package_id", ""))
                package = require_package(package_id)
                result = run_controller(
                    "firmware-verify",
                    ["-PackagePath", str(package["path"])],
                    timeout=45,
                )
                output = "\n".join(
                    value
                    for value in (result["stdout"], result["stderr"])
                    if value
                )
                self._json(
                    {
                        "ok": result["ok"],
                        "output": output,
                        "exit_code": result["exit_code"],
                    },
                    HTTPStatus.OK if result["ok"] else HTTPStatus.BAD_GATEWAY,
                )
            except Exception as exc:
                self._error(str(exc), HTTPStatus.BAD_GATEWAY)
            return

        self._error("Endpoint not found", HTTPStatus.NOT_FOUND)

    def do_DELETE(self) -> None:
        path = urlparse(self.path).path
        if not self._require_auth():
            return

        if path.startswith("/v1/packages/"):
            package_id = path.rsplit("/", 1)[-1]
            with STATE.packages_lock:
                entry = STATE.packages.pop(package_id, None)
                STATE.save_registry()
            if not entry:
                self._error("Package not found", HTTPStatus.NOT_FOUND)
                return
            Path(str(entry["path"])).unlink(missing_ok=True)
            self._json({"ok": True})
            return

        self._error("Endpoint not found", HTTPStatus.NOT_FOUND)


def main() -> int:
    port = int(os.environ.get("HOTFETCHED_A1_AGENT_PORT", DEFAULT_PORT))
    STATE.pid_path.write_text(str(os.getpid()), encoding="ascii")
    STATE.log(f"agent {AGENT_VERSION} starting on {HOST}:{port}")

    server = ThreadingHTTPServer((HOST, port), Handler)
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        return 130
    finally:
        server.server_close()
        STATE.pid_path.unlink(missing_ok=True)
        STATE.log("agent stopped")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        try:
            STATE.log(
                f"fatal: {type(exc).__name__}: {exc} "
                f"{traceback.format_exc(limit=4)}"
            )
        except Exception:
            pass
        raise
